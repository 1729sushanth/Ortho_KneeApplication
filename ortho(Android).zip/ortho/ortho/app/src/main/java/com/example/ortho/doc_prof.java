package com.example.ortho;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

public class doc_prof extends AppCompatActivity {

    private TextView did,dname,dgndr,dage,dcntct,dmail;
    private String username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.doc_prof);
        username = getIntent().getStringExtra("username");
        did = findViewById(R.id.textView49);
        dname=findViewById(R.id.textView48);
        dgndr=findViewById(R.id.textView50);
        dage =findViewById(R.id.textView51);
        dcntct=findViewById(R.id.textView52);
        dmail=findViewById(R.id.textView53);
        Button bt =findViewById(R.id.button11);
        bt.setOnClickListener(view -> {
            sendLoginRequest1(username);
        });
        sendLoginRequest(username);
    }

    private void sendLoginRequest(final String doc_id) {
        // Adjust the URL to include parameters in the GET request
        String URL = ip.ipn + "doc_profile.php?doc_id=" + doc_id ;

        StringRequest stringRequest = new StringRequest(Request.Method.GET, URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        handleResponse(response);
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                handleError(error);
            }
        });

        // Customize the retry policy
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                60000, DefaultRetryPolicy.DEFAULT_MAX_RETRIES, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        // Initialize the Volley request queue and add the request
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(stringRequest);
    }

    private void handleResponse(String response) {
        Log.d("JSON Response", response);

        try {
            JSONObject jsonObject = new JSONObject(response);
            boolean status = jsonObject.getBoolean("status");
            String message = jsonObject.getString("message");

            if (status) {
                Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
                JSONObject data = jsonObject.getJSONObject("data");
                // Access attributes in data object and set them to TextViews
                String docId = data.getString("doc_id");
                String docName = data.getString("doc_name");
                String docGender = data.getString("doc_gender");
                String docAge = data.getString("doc_age");
                String docContact = data.getString("doc_contact");
                String docMail = data.getString("doc_mail");

                // Set attributes to respective TextViews
                // Assuming you have TextViews with ids tvDocId, tvDocName, etc.
                did.setText(docId);
                dname.setText(docName);
                dgndr.setText(docGender);
                dage.setText(docAge);
                dcntct.setText(docContact);
                dmail.setText(docMail);
            } else {
                Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
            }
        } catch (JSONException e) {
            e.printStackTrace();
            Toast.makeText(this, "Error parsing JSON", Toast.LENGTH_SHORT).show();
        }
    }


    // Handle network request errors
    private void handleError(VolleyError error) {
        if (error instanceof TimeoutError) {
            Toast.makeText(this, "Request timed out. Check your internet connection.", Toast.LENGTH_SHORT).show();
        } else {
            System.out.println(error.toString().trim());
            Toast.makeText(this, error.toString().trim(), Toast.LENGTH_SHORT).show();
        }
    }

    private void sendLoginRequest1(final String doc_id) {
        // Adjust the URL to include parameters in the GET request
        String URL = ip.ipn + "doc_profile.php?doc_id=" + doc_id ;

        StringRequest stringRequest = new StringRequest(Request.Method.GET, URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        handleResponse1(response);
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                handleError(error);
            }
        });

        // Customize the retry policy
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                60000, DefaultRetryPolicy.DEFAULT_MAX_RETRIES, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        // Initialize the Volley request queue and add the request
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(stringRequest);
    }

    private void handleResponse1(String response) {
        Log.d("JSON Response", response);

        try {
            JSONObject jsonObject = new JSONObject(response);
            boolean status = jsonObject.getBoolean("status");
            String message = jsonObject.getString("message");

            if (status) {
                Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
                JSONObject data = jsonObject.getJSONObject("data");
                // Access attributes in data object and set them to TextViews
                String docId = data.getString("doc_id");
                String docName = data.getString("doc_name");
                String docGender = data.getString("doc_gender");
                String docAge = data.getString("doc_age");
                String docContact = data.getString("doc_contact");
                String docMail = data.getString("doc_mail");

                Intent it = new Intent(this, doc_edt.class);
                it.putExtra("username",docId);
                it.putExtra("name",docName);
                it.putExtra("age",docAge);
                it.putExtra("gndr",docGender);
                it.putExtra("cntct",docContact);
                it.putExtra("mail",docMail);
                startActivity(it);


            } else {
                Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
            }
        } catch (JSONException e) {
            e.printStackTrace();
            Toast.makeText(this, "Error parsing JSON", Toast.LENGTH_SHORT).show();
        }
    }

}