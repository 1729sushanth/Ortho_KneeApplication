package com.example.ortho;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.RadioButton;
import android.widget.SeekBar;
import android.widget.TextView;

public class Qstnrs1 extends AppCompatActivity {
    private TextView q,t,q1,q2,q3,q4,q5,q6,q7,n,ts2,ts3;
    private RadioButton q1c1,q1c2,q1c3,q1c4,q1c5,q4c1,q4c2,q4c3,q4c4,q4c5,q5c1,q5c2,q5c3,q5c4,q5c5,q6c1,q6c2,q7c1,q7c2,q7c3,q7c4,q7c5;

    private String username,lang;
    private SeekBar skb2,skb3;
    private int v1,v2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.qstnrs1);
        username = getIntent().getStringExtra("username");
        lang = getIntent().getStringExtra("lang");


        q=findViewById(R.id.textView71);
        t=findViewById(R.id.textView82);

        q1=findViewById(R.id.textView74);
        q1c1=findViewById(R.id.radioButton34);
        q1c2=findViewById(R.id.radioButton44);
        q1c3=findViewById(R.id.radioButton54);
        q1c4=findViewById(R.id.radioButton64);
        q1c5=findViewById(R.id.radioButton74);

        q2=findViewById(R.id.textView782);
        ts2 = findViewById(R.id.textView79);
        skb2 = findViewById(R.id.seekBar2);
        skb2.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                ts2.setText("" + i);
                v1 = i;
            }
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        });


        q3=findViewById(R.id.textView78);
        ts3 = findViewById(R.id.textView80);
        skb3 = findViewById(R.id.seekBar);
        skb3.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                ts3.setText("" + i);
                v2 = i;
            }
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        });

        q4=findViewById(R.id.textView73);
        q4c1=findViewById(R.id.radioButton33);
        q4c2=findViewById(R.id.radioButton43);
        q4c3=findViewById(R.id.radioButton53);
        q4c4=findViewById(R.id.radioButton63);
        q4c5=findViewById(R.id.radioButton73);

        q5=findViewById(R.id.textView72);
        q5c1=findViewById(R.id.radioButton32);
        q5c2=findViewById(R.id.radioButton42);
        q5c3=findViewById(R.id.radioButton52);
        q5c4=findViewById(R.id.radioButton62);
        q5c5=findViewById(R.id.radioButton72);

        q6=findViewById(R.id.textView77);
        q6c1=findViewById(R.id.radioButton31);
        q6c2=findViewById(R.id.radioButton41);

        q7=findViewById(R.id.textView7);
        q7c1=findViewById(R.id.radioButton3);
        q7c2=findViewById(R.id.radioButton4);
        q7c3=findViewById(R.id.radioButton5);
        q7c4=findViewById(R.id.radioButton6);
        q7c5=findViewById(R.id.radioButton7);

        n= findViewById(R.id.textView75);
        n.setOnClickListener(view -> {
            int score=v1+v2;
            if(q1c1.isChecked()){
                score=score+4;
            }
            else if(q1c2.isChecked()){
                score=score+3;
            }
            else if(q1c3.isChecked()){
                score=score+2;
            }
            else if(q1c4.isChecked()){
                score=score+1;
            }
            else if(q1c5.isChecked()){
                score=score+0;
            }

            if(q4c1.isChecked()){
                score=score+4;
            }
            else if(q4c2.isChecked()){
                score=score+3;
            }
            else if(q4c3.isChecked()){
                score=score+2;
            }
            else if(q4c4.isChecked()){
                score=score+1;
            }
            else if(q4c5.isChecked()){
                score=score+0;
            }

            if(q5c1.isChecked()){
                score=score+4;
            }
            else if(q5c2.isChecked()){
                score=score+3;
            }
            else if(q5c3.isChecked()){
                score=score+2;
            }
            else if(q5c4.isChecked()){
                score=score+1;
            }
            else if(q5c5.isChecked()){
                score=score+0;
            }

            if(q6c1.isChecked()){
                score=score+0;
            }
            else if(q6c2.isChecked()){
                score=score+1;
            }

            if(q7c1.isChecked()){
                score=score+4;
            }
            else if(q7c2.isChecked()){
                score=score+3;
            }
            else if(q7c3.isChecked()){
                score=score+2;
            }
            else if(q7c4.isChecked()){
                score=score+1;
            }
            else if(q7c5.isChecked()){
                score=score+0;
            }


            System.out.println(score);
            Intent intent = new Intent(this, qstnrs2.class);
            intent.putExtra("username",username);
            intent.putExtra("lang",lang);
            intent.putExtra("score",String.valueOf(score));
            startActivity(intent);
        });



        if(lang.equals("1")){
            q1.setText("1. குறிப்பிடத்தக்க முழங்கால் வலி இல்லாமல் நீங்கள் செய்யக்கூடிய மிக உயர்ந்த அளவிலான செயல்பாடு என்ன?");
            q1c1.setText("கூடைப்பந்து அல்லது கால்பந்தில் ஜம்பிங் அல்லது பிவோட்டிங் போன்ற மிகவும் கடினமான நடவடிக்கைகள்");
            q1c2.setText("கடுமையான உடல் உழைப்பு, பனிச்சறுக்கு அல்லது டென்னிஸ் போன்ற கடுமையான நடவடிக்கைகள்");
            q1c3.setText("மிதமான உடல் உழைப்பு, ஓடுதல் அல்லது ஜாகிங் போன்ற மிதமான நடவடிக்கைகள்");
            q1c4.setText("நடைபயிற்சி, வீட்டு வேலைகள் அல்லது முற்றத்தில் வேலை செய்வது போன்ற இலகுவான செயல்பாடுகள்");
            q1c5.setText("முழங்கால் வலி காரணமாக மேற்கூறிய செயல்களில் எதையும் செய்ய முடியவில்லை");

            q2.setText("2. கடந்த 4 வாரங்களில், அல்லது உங்கள் காயத்திலிருந்து, உங்களுக்கு எத்தனை முறை வலி ஏற்பட்டது?");
            q3.setText("3. உங்களுக்கு வலி இருந்தால், அது எவ்வளவு கடுமையானது?");

            q4.setText("4. கடந்த 4 வாரங்களில், அல்லது உங்கள் காயம் காரணமாக, உங்கள் முழங்கால் எவ்வளவு கடினமாகவோ அல்லது வீக்கமாகவோ இருந்தது?");
            q4c1.setText("இல்லவே இல்லை");
            q4c2.setText("லேசாக");
            q4c3.setText("மிதமாக");
            q4c4.setText("மிகவும்");
            q4c5.setText("மிகவும்");

            q5.setText("5. உங்கள் முழங்காலில் குறிப்பிடத்தக்க வீக்கம் இல்லாமல் நீங்கள் செய்யக்கூடிய மிக உயர்ந்த அளவிலான செயல்பாடு என்ன?");
            q5c1.setText("கூடைப்பந்து அல்லது கால்பந்தில் ஜம்பிங் அல்லது பிவோட்டிங் போன்ற மிகவும் கடினமான நடவடிக்கைகள்");
            q5c2.setText("கடுமையான உடல் உழைப்பு, பனிச்சறுக்கு அல்லது டென்னிஸ் போன்ற கடுமையான நடவடிக்கைகள்");
            q5c3.setText("மிதமான உடல் உழைப்பு, ஓடுதல் அல்லது ஜாகிங் போன்ற மிதமான நடவடிக்கைகள்");
            q5c4.setText("நடைபயிற்சி, வீட்டு வேலைகள் அல்லது முற்றத்தில் வேலை செய்வது போன்ற இலகுவான செயல்பாடுகள்");
            q5c5.setText("முழங்கால் வலி காரணமாக மேற்கூறிய செயல்களில் எதையும் செய்ய முடியவில்லை");

            q6.setText("6. கடந்த 4 வாரங்களில், அல்லது உங்கள் காயம் காரணமாக, உங்கள் முழங்கால் பிடிபட்டதா?");
            q6c1.setText("ஆம்");
            q6c2.setText("இல்லை");


            q7.setText("7. உங்கள் முழங்காலில் குறிப்பிடத்தக்க வழி இல்லாமல் நீங்கள் செய்யக்கூடிய மிக உயர்ந்த அளவிலான செயல்பாடு என்ன?");
            q7c1.setText("கூடைப்பந்து அல்லது கால்பந்தில் ஜம்பிங் அல்லது பிவோட்டிங் போன்ற மிகவும் கடினமான நடவடிக்கைகள்");
            q7c2.setText("கடுமையான உடல் உழைப்பு, பனிச்சறுக்கு அல்லது டென்னிஸ் போன்ற கடுமையான நடவடிக்கைகள்");
            q7c3.setText("மிதமான உடல் உழைப்பு, ஓடுதல் அல்லது ஜாகிங் போன்ற மிதமான நடவடிக்கைகள்");
            q7c4.setText("நடைபயிற்சி, வீட்டு வேலைகள் அல்லது முற்றத்தில் வேலை செய்வது போன்ற இலகுவான செயல்பாடுகள்");
            q7c5.setText("முழங்கால் வலி காரணமாக மேற்கூறிய செயல்களில் எதையும் செய்ய முடியவில்லை");

            t.setText("ப: அறிகுறிகள்");
            q.setText("கேள்விகள் ");
            n.setText("அடுத்தது");
            q1c1.setTextSize(12);
            q1c2.setTextSize(12);
            q1c3.setTextSize(12);
            q1c4.setTextSize(12);
            q1c5.setTextSize(12);

            q5c1.setTextSize(12);
            q5c2.setTextSize(12);
            q5c3.setTextSize(12);
            q5c4.setTextSize(12);
            q5c5.setTextSize(12);

            q7c1.setTextSize(12);
            q7c2.setTextSize(12);
            q7c3.setTextSize(12);
            q7c4.setTextSize(12);
            q7c5.setTextSize(12);
        }



    }
}