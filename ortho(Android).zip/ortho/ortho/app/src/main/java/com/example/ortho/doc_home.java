package com.example.ortho;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.widget.Toolbar;


import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;


import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.navigation.NavigationView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class doc_home extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {


    private String username;

    private List<Patient> patientList;
    private ListView gridView;
    private SearchView searchView;
    private patientAdapter adapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doc_home);
        username = getIntent().getStringExtra("username");

        ImageView im1 = findViewById(R.id.toolbar_image);
        im1.setOnClickListener(view -> {

            Intent sendIntent = new Intent();
            sendIntent.setAction(Intent.ACTION_SEND);
            sendIntent.putExtra(Intent.EXTRA_TEXT, "Hello this is doctor ....");
            sendIntent.setType("text/plain");
            sendIntent.setPackage("com.whatsapp");
            //startActivity(Intent.createChooser(sendIntent, ""));
            startActivity(sendIntent);
        });
        gridView = findViewById(R.id.ListView);
        patientList = new ArrayList<>();

        adapter = new patientAdapter(this, patientList);
        gridView.setAdapter(adapter);

        // Set item click listener to open pat_view activity with selected patient details
        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Patient selectedPatient = patientList.get(position);
                Intent intent = new Intent(doc_home.this, pat_dtls.class);
                intent.putExtra("username", selectedPatient.getuser());
                startActivity(intent);
            }
        });

        String url = ip.ipn +"pat_list.php";
        makeRequest(url);
        TextView t1 = findViewById(R.id.textView60);
        t1.setOnClickListener(view -> {
            Intent it = new Intent(this,pat_lst.class);
            it.putExtra("username", username);
            startActivity(it);
        });
        Button bt = findViewById(R.id.button13);
        bt.setOnClickListener(view -> {
            Intent it = new Intent(this, add_pat.class);
            it.putExtra("username", username);
            startActivity(it);
        });
        Button b1 = findViewById(R.id.button14);
        b1.setOnClickListener(view -> {
            Intent it = new Intent(this, video_lst.class);
            startActivity(it);
        });

        Button b2 = findViewById(R.id.button15);
        b2.setOnClickListener(view -> {
            Intent it = new Intent(this, vid_upld.class);
            it.putExtra("username", username);
            startActivity(it);
        });
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);

        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.activity_main_drawer, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.profile) { // Use R.id.profile here
            Log.d("MenuItemClicked", "Profile clicked");
            startActivity(new Intent(this, doc_prof.class));
            return true;
        } else if (id == R.id.logout) { // Use R.id.logout here
            startActivity(new Intent(this, MainActivity.class));
            return true;
        }
        return super.onOptionsItemSelected(item);
    }


    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.profile) {
            Intent it =new Intent(this, doc_prof.class);
            it.putExtra("username",username);
            startActivity(it);
            return true;
        } else if (id == R.id.logout) {
            startActivity(new Intent(this, MainActivity.class));
            return true;
        }
        return false;
    }

    private void makeRequest(String url) {
        StringRequest stringRequest = new StringRequest(
                Request.Method.POST,
                url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        System.out.println(response);
                        Log.d("Volley Response", response);
                        parseResponse(response);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e("Volley Error", error.toString());
                        Toast.makeText(doc_home.this, "Error fetching data", Toast.LENGTH_SHORT).show();
                    }
                }
        );

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

    private void parseResponse(String response) {
        Log.d("JSON Response", response);

        try {
            JSONObject jsonResponse = new JSONObject(response);
            JSONArray data = jsonResponse.getJSONArray("data");

            // Ensure there is data in the response
            if (data.length() > 0) {
                // Clear existing data
                patientList.clear();

                // Iterate through the data array and add patients to the list
                for (int i = 0; i < data.length(); i++) {
                    JSONObject patientObject = data.getJSONObject(i);
                    String patientId = patientObject.getString("pat_id");
                    String name = patientObject.getString("pat_name");
                    String age = patientObject.getString("pat_age");
                    String dp = patientObject.getString("dp");

                    // Add the patient to the list
                    patientList.add(new Patient(name, patientId,age,dp));
                }

                // Notify the adapter that the data set has changed
                adapter.notifyDataSetChanged();
            } else {
                // Handle case where there is no data in the response
                Log.e("Handle Response", "No data in the response");
            }
        } catch (JSONException e) {
            e.printStackTrace();
            // Handle JSON parsing error
            Log.e("Handle Response", "Error parsing JSON response: " + e.getMessage());
        }
    }

    private void filterParentList(String searchText) {
        Log.d("SearchText", searchText);

        List<Patient> filteredList = new ArrayList<>();

        // Trim leading and trailing whitespaces
        searchText = searchText.trim().toLowerCase();

        for (Patient patient : patientList) {
            Log.d("PatientName", patient.getName());
            if (patient.getName().toLowerCase().contains(searchText)) {
                filteredList.add(patient);
            }
        }

        // Update the adapter with the filtered list
        adapter.setFilteredList(filteredList);
    }


}
