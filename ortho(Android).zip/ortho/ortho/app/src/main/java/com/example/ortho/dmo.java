package com.example.ortho;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;

public class dmo extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dmo);
        String username = getIntent().getStringExtra("username");
        LinearLayout b1 = findViewById(R.id.d3);
        b1.setOnClickListener(view -> {
            Intent it = new Intent(this, video_lst.class);
            startActivity(it);
        });
        LinearLayout im1 = findViewById(R.id.d4);
        im1.setOnClickListener(view -> {

            Intent sendIntent = new Intent();
            sendIntent.setAction(Intent.ACTION_SEND);
            sendIntent.putExtra(Intent.EXTRA_TEXT, "Hello doctor!!!");
            sendIntent.setType("text/plain");
            sendIntent.setPackage("com.whatsapp");
            //startActivity(Intent.createChooser(sendIntent, ""));
            startActivity(sendIntent);
        });
        LinearLayout b3= findViewById(R.id.d2);
        b3.setOnClickListener(view -> {
            Intent it = new Intent(this, pdf_dis.class);
            startActivity(it);
        });
        LinearLayout bt2 = findViewById(R.id.b2);
        bt2.setOnClickListener(view -> {
            Intent it = new Intent(this, view_task.class);
            it.putExtra("username",username);
            startActivity(it);
        });
        LinearLayout bt4 = findViewById(R.id.b1);
        bt4.setOnClickListener(view -> {
            Intent it = new Intent(this, tdy_tsk.class);
            it.putExtra("username",username);
            startActivity(it);
        });
        LinearLayout bb3 = findViewById(R.id.b3);
        bb3.setOnClickListener(view -> {
            Intent it = new Intent(this, pat_home.class);
            it.putExtra("username",username);
            startActivity(it);
        });
        LinearLayout bt5 = findViewById(R.id.d1);
        bt5.setOnClickListener(view -> {
            Dialog myDialog = new Dialog(this);
            myDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
            //myDialog.setCancelable(false);
            myDialog.setContentView(R.layout.lang);
            myDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            myDialog.show();
            Button yes = myDialog.findViewById(R.id.button11);
            Button no = myDialog.findViewById(R.id.button9);
            yes.setOnClickListener(view1 -> {
                Intent intent = new Intent(this, Qstnrs1.class);
                intent.putExtra("username",username);
                intent.putExtra("lang","1");
                startActivity(intent);
            });
            no.setOnClickListener(view1 -> {
                Intent intent = new Intent(this, Qstnrs1.class);
                intent.putExtra("username",username);
                intent.putExtra("lang","0");
                startActivity(intent);
            });
        });

        ImageView im = findViewById(R.id.imageView2);
        im.setOnClickListener(view -> {
            startActivity(new Intent(this, MainActivity.class));
        });
    }
}