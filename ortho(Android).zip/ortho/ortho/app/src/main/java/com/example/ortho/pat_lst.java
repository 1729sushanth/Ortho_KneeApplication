package com.example.ortho;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class pat_lst extends AppCompatActivity {

    private List<Patient> patientList;
    private ListView gridView;
    private SearchView searchView;
    private patientAdapter2 adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.pat_lst);
        searchView = findViewById(R.id.searchView);
        gridView = findViewById(R.id.ListView);
        patientList = new ArrayList<>();

        adapter = new patientAdapter2(this, patientList);
        gridView.setAdapter(adapter);

        // Set item click listener to open pat_view activity with selected patient details
        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Patient selectedPatient = patientList.get(position);
                Intent intent = new Intent(pat_lst.this, pat_dtls.class);
                intent.putExtra("username", selectedPatient.getuser());
                startActivity(intent);
            }
        });

        String url = ip.ipn +"allpat_list.php";
        makeRequest(url);
        setupSearchView();
    }

    private void makeRequest(String url) {
        StringRequest stringRequest = new StringRequest(
                Request.Method.POST,
                url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        System.out.println(response);
                        Log.d("Volley Response", response);
                        parseResponse(response);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e("Volley Error", error.toString());
                        Toast.makeText(pat_lst.this, "Error fetching data", Toast.LENGTH_SHORT).show();
                    }
                }
        );

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

    private void parseResponse(String response) {
        Log.d("JSON Response", response);

        try {
            JSONObject jsonResponse = new JSONObject(response);
            JSONArray data = jsonResponse.getJSONArray("data");

            // Ensure there is data in the response
            if (data.length() > 0) {
                // Clear existing data
                patientList.clear();

                // Iterate through the data array and add patients to the list
                for (int i = 0; i < data.length(); i++) {
                    JSONObject patientObject = data.getJSONObject(i);
                    String patientId = patientObject.getString("pat_id");
                    String name = patientObject.getString("pat_name");
                    String age = patientObject.getString("pat_age");
                    String dp = patientObject.getString("dp");

                    // Add the patient to the list
                    patientList.add(new Patient(name, patientId,age,dp));
                }

                // Notify the adapter that the data set has changed
                adapter.notifyDataSetChanged();
            } else {
                // Handle case where there is no data in the response
                Log.e("Handle Response", "No data in the response");
            }
        } catch (JSONException e) {
            e.printStackTrace();
            // Handle JSON parsing error
            Log.e("Handle Response", "Error parsing JSON response: " + e.getMessage());
        }
    }

    private void filterParentList(String searchText) {
        Log.d("SearchText", searchText);

        List<Patient> filteredList = new ArrayList<>();

        // Trim leading and trailing whitespaces
        searchText = searchText.trim().toLowerCase();

        for (Patient patient : patientList) {
            Log.d("PatientName", patient.getuser());
            if (patient.getuser().toLowerCase().contains(searchText) || patient.getName().toLowerCase().contains(searchText)) {
                filteredList.add(patient);
            }

        }

        // Update the adapter with the filtered list
        adapter.setFilteredList(filteredList);
    }

    private void setupSearchView() {
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                // Filter the parent list based on the entered text
                filterParentList(newText);
                return true;
            }
        });
    }



}