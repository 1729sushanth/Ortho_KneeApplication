package com.example.ortho;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button bt1 = findViewById(R.id.button);
        bt1.setOnClickListener(v -> {
            Intent it = new Intent(this, doc_log.class);
            startActivity(it);
        });
        Button bt2 = findViewById(R.id.button2);
        bt2.setOnClickListener(v -> {
            Intent it = new Intent(this, pat_log.class);
            startActivity(it);
        });
    }
}