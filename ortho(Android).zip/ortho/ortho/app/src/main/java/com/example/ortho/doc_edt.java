package com.example.ortho;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

public class doc_edt extends AppCompatActivity {

    private String username,name,age,gndr,cntct,mail;
    private TextView did;
    private EditText dname,dgndr,dage,dcntct,dmail;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.doc_edt);
        username = getIntent().getStringExtra("username");
        name = getIntent().getStringExtra("name");
        age = getIntent().getStringExtra("age");
        gndr = getIntent().getStringExtra("gndr");
        cntct = getIntent().getStringExtra("cntct");
        mail = getIntent().getStringExtra("mail");
        did = findViewById(R.id.textView49);
        dname=findViewById(R.id.textView48);
        dgndr=findViewById(R.id.textView50);
        dage =findViewById(R.id.textView51);
        dcntct=findViewById(R.id.textView52);
        dmail=findViewById(R.id.textView53);

        did.setText(username);
        dname.setText(name);
        dage.setText(age);
        dcntct.setText(cntct);
        dgndr.setText(gndr);
        dmail.setText(mail);

        Button bt = findViewById(R.id.button11);
        bt.setOnClickListener(view -> {

            name= dname.getText().toString().trim();
            age= dage.getText().toString().trim();
            gndr= dgndr.getText().toString().trim();
            cntct= dcntct.getText().toString().trim();
            mail= dmail.getText().toString().trim();

            sendLoginRequest(username);
        });


    }

    private void sendLoginRequest(final String username) {
        String URL = ip.ipn+"edit_doc.php";
        StringRequest stringRequest = new StringRequest(Request.Method.POST, URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        handleResponse(response,username);
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                handleError(error);
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                // Send the username and password as POST parameters
                Map<String, String> data = new HashMap<>();

                data.put("doc_id", username);
                data.put("doc_name", name);
                data.put("doc_age", age);
                data.put("doc_gender", gndr);
                data.put("doc_contact", cntct);
                data.put("doc_mail", mail);



                return data;
            }
        };

        // Customize the retry policy
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                60000, DefaultRetryPolicy.DEFAULT_MAX_RETRIES, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        // Initialize the Volley request queue and add the request
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

    // Handle the JSON response
    private void handleResponse(String response,String username) {
        Log.d("JSON Response", response);

        // Handle your JSON response here without assuming a 'status' field
        // You can parse the response and handle success/failure accordingly
        try {
            // Example: Check if the response contains "success"
            if (response.toLowerCase().contains("true")) {
                Toast.makeText(this, "Sign Up successful", Toast.LENGTH_SHORT).show();

                Intent intent = new Intent(this, doc_home.class);
                intent.putExtra("username", username);
                startActivity(intent);
                System.out.println("aaa "+username);


            } else {
                Toast.makeText(this, "Sign Up failed", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Error parsing JSON", Toast.LENGTH_SHORT).show();
        }
    }

    private void handleError(VolleyError error) {
        System.out.println("boooooo");
    }
}