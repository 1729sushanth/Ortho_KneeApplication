package com.example.ortho;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class pat_dtls extends AppCompatActivity {
    private String username;
    private ImageView im;
    private TextView pid,name,cntct,age,gndr,hght,wght,dos,wtc;
    private String spid,sname,scntct,sage,sgndr,shght,swght,sdos,swtc;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.pat_dtls);
        username = getIntent().getStringExtra("username");
        pid = findViewById(R.id.editText41);
        name = findViewById(R.id.editText40);
        cntct = findViewById(R.id.editText42);
        age = findViewById(R.id.editText43);
        gndr = findViewById(R.id.editText44);
        hght = findViewById(R.id.editText45);
        wght = findViewById(R.id.editText48);
        dos = findViewById(R.id.editText47);
        im = findViewById(R.id.imageView4);
        Button bt2 = findViewById(R.id.button9);
        bt2.setOnClickListener(view -> {
            Intent it = new Intent(this, view_task.class);
            it.putExtra("username",username);
            startActivity(it);
        });
        Button bt1 = findViewById(R.id.button10);
        bt1.setOnClickListener(view -> {
            spid=pid.getText().toString().trim();
            sname=name.getText().toString().trim();
            sage=age.getText().toString().trim();
            sgndr=gndr.getText().toString().trim();
            scntct=cntct.getText().toString().trim();
            shght=hght.getText().toString().trim();
            swght=wght.getText().toString().trim();
            sdos=dos.getText().toString().trim();

            Intent it = new Intent(this, pat_dtls2.class);
            it.putExtra("username",spid);
            it.putExtra("name",sname);
            it.putExtra("age",sage);
            it.putExtra("contact",scntct);
            it.putExtra("gender",sgndr);
            it.putExtra("height",shght);
            it.putExtra("weight",swght);
            it.putExtra("dos",sdos);

            startActivity(it);

        });
        fetchData(username);
    }
    private void fetchData(String username) {
        // Replace "http://192.168.156.100:80/login/prof.php" with your actual API endpoint
        String apiUrl = ip.ipn +"pat_details.php";

        // Append the username as a parameter to the URL
        StringRequest stringRequest = new StringRequest(Request.Method.POST, apiUrl,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        handleResponse(response);
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                handleError(error);
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                // Send the username as a POST parameter
                Map<String, String> data = new HashMap<>();
                data.put("pat_id", username);

                // Log the parameters for debugging
                Log.d("Volley Request", "Params: " + data.toString());

                return data;
            }
        };

        Volley.newRequestQueue(this).add(stringRequest);

    }


    private void handleResponse(String response) {
        Log.d("JSON Response", response);
        try {
            JSONObject jsonResponse = new JSONObject(response);
            boolean status = jsonResponse.getBoolean("status");
            String message = jsonResponse.getString("message");

            if (status) {
                Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
                JSONArray dataArray = jsonResponse.getJSONArray("data");
                JSONObject data = dataArray.getJSONObject(0);
                // Access attributes in data object and set them to TextViews
                String docId = data.getString("pat_id");
                String docName = data.getString("pat_name");
                String docGender = data.getString("pat_gender");
                String docAge = data.getString("pat_age");
                String docContact = data.getString("pat_contact");
                String docMail = data.getString("pat_height");
                String w = data.getString("pat_weight");
                String d = data.getString("pat_dos");
                String base64Image = data.getString("dp");
                // Set attributes to respective TextViews
                // Assuming you have TextViews with ids tvDocId, tvDocName, etc.
                pid.setText(docId);
                name.setText(docName);
                gndr.setText(docGender);
                age.setText(docAge);
                cntct.setText(docContact);
                hght.setText(docMail);
                wght.setText(w);
                dos.setText(d);

                if (base64Image != null && !base64Image.isEmpty()) {
                    byte[] decodedImageBytes = Base64.decode(base64Image, Base64.DEFAULT);
                    Bitmap decodedBitmap = BitmapFactory.decodeByteArray(decodedImageBytes, 0, decodedImageBytes.length);
                    Bitmap circularBitmap = Utils.getCircleBitmap(decodedBitmap);
                    im.setImageBitmap(circularBitmap);
                }

            } else {
                Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
            }
        } catch (JSONException e) {
            e.printStackTrace();
            Toast.makeText(this, "Error parsing JSON", Toast.LENGTH_SHORT).show();
        }
    }



    private void handleError(VolleyError error) {
        System.out.println("boooooo");
    }
}