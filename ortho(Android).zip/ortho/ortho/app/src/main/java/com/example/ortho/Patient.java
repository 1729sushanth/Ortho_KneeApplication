package com.example.ortho;

public class Patient {

    private String name,user,age,dp;



    public Patient(String name,  String user,String age,String dp) {
        this.name = name;
        this.age = age;
        this.user = user;
        this.dp=dp;

    }

    public String getName() {
        return name;
    }
    public String getuser() {
        return user;
    }
    public String getage() {
        return age;
    }


    public String getdp() {
        return dp;
    }
}
