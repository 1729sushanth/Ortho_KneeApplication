package com.example.ortho;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class pat_home extends AppCompatActivity {
    private String username;
    private ImageView im;
    private TextView pid,name,cntct,age,gndr,hght,wght,dos,wtc;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.pat_home);
        String username = getIntent().getStringExtra("username");
        im = findViewById(R.id.imageView4);
        pid = findViewById(R.id.textView16);
        name = findViewById(R.id.textView17);
        cntct = findViewById(R.id.textView18);
        age = findViewById(R.id.textView19);
        gndr = findViewById(R.id.textView20);
        hght = findViewById(R.id.textView21);
        wght = findViewById(R.id.textView22);
        dos = findViewById(R.id.textView23);
        wtc = findViewById(R.id.textView24);

        ImageView im = findViewById(R.id.imageView2);
        im.setOnClickListener(view -> {
            startActivity(new Intent(this, MainActivity.class));
        });
        fetchData(username);
    }

    private boolean isAppInstalled(PackageManager pm, String packageName) {
        try {
            pm.getPackageInfo(packageName, PackageManager.GET_ACTIVITIES);
            return true;
        } catch (PackageManager.NameNotFoundException e) {
            return false;
        }
    }
    private void fetchData(String username) {
        // Replace "http://192.168.156.100:80/login/prof.php" with your actual API endpoint
        String apiUrl = ip.ipn +"pat_details.php";

        // Append the username as a parameter to the URL
        StringRequest stringRequest = new StringRequest(Request.Method.POST, apiUrl,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        handleResponse(response);
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                handleError(error);
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                // Send the username as a POST parameter
                Map<String, String> data = new HashMap<>();
                data.put("pat_id", username);

                // Log the parameters for debugging
                Log.d("Volley Request", "Params: " + data.toString());

                return data;
            }
        };

        Volley.newRequestQueue(this).add(stringRequest);

    }


    private void handleResponse(String response) {
        Log.d("JSON Response", response);
        try {
            JSONObject jsonResponse = new JSONObject(response);
            boolean status = jsonResponse.getBoolean("status");
            String message = jsonResponse.getString("message");

            if (status) {
                Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
                JSONArray dataArray = jsonResponse.getJSONArray("data");
                JSONObject data = dataArray.getJSONObject(0);
                // Access attributes in data object and set them to TextViews
                String docId = data.getString("pat_id");
                String docName = data.getString("pat_name");
                String docGender = data.getString("pat_gender");
                String docAge = data.getString("pat_age");
                String docContact = data.getString("pat_contact");
                String docMail = data.getString("pat_height");
                String w = data.getString("pat_weight");
                String d = data.getString("pat_dos");
                String we = data.getString("weight_to_carry");
                String base64Image = data.getString("dp");
                // Set attributes to respective TextViews
                // Assuming you have TextViews with ids tvDocId, tvDocName, etc.
                pid.setText(docId);
                name.setText(docName);
                gndr.setText(docGender);
                age.setText(docAge);
                cntct.setText(docContact);
                hght.setText(docMail);
                wght.setText(w);
                dos.setText(d);
                wtc.setText(we);
                if (base64Image != null && !base64Image.isEmpty()) {
                    byte[] decodedImageBytes = Base64.decode(base64Image, Base64.DEFAULT);
                    Bitmap decodedBitmap = BitmapFactory.decodeByteArray(decodedImageBytes, 0, decodedImageBytes.length);
                    Bitmap circularBitmap = Utils.getCircleBitmap(decodedBitmap);
                    im.setImageBitmap(circularBitmap);
                }
            } else {
                Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
            }
        } catch (JSONException e) {
            e.printStackTrace();
            Toast.makeText(this, "Error parsing JSON", Toast.LENGTH_SHORT).show();
        }
    }



    private void handleError(VolleyError error) {
        System.out.println("boooooo");
    }
}