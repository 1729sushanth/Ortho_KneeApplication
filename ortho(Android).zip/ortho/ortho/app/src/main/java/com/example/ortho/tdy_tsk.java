package com.example.ortho;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class tdy_tsk extends AppCompatActivity {
    private String username,feed;
    private ListView listView;
    private Button submitButton;
    private TaskAdapter adapter;
    private List<Task> tasks;
    private EditText efeed;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dy_tsk);
        username = getIntent().getStringExtra("username");
        listView = findViewById(R.id.ListView);
        submitButton = findViewById(R.id.button17);
        efeed=findViewById(R.id.editTextText5);
        tasks = new ArrayList<>(); // Initialize the tasks list
        adapter = new TaskAdapter(this, tasks); // Initialize the adapter
        listView.setAdapter(adapter); // Set the adapter to the ListView
        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                List<Task> checkedTasks = new ArrayList<>();
                for (Task task : tasks) {
                    if (task.isChecked()) {
                        checkedTasks.add(task);
                    }
                }
                Log.d("CheckedTasks", "Number of checked tasks: " + checkedTasks.size());


                feed=efeed.getText().toString().trim();


                if (checkedTasks.isEmpty()) {
                    Toast.makeText(tdy_tsk.this, "No tasks selected", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (feed.isEmpty()) {
                    Toast.makeText(tdy_tsk.this, "Feedback is Empty!!!", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Prepare the selected task names as a JSON array
                JSONArray jsonArray = new JSONArray();
                for (Task task : checkedTasks) {
                    jsonArray.put(task.getName());
                }

                // Make a network request to send the selected task names to PHP
                sendSelectedTasks(jsonArray.toString());
            }
        });

        // Remove the redundant initialization of tasks and call sendLoginRequest
        sendLoginRequest(username);
    }

    private void sendLoginRequest(final String doc_id) {
        // Adjust the URL to include parameters in the GET request
        String URL = ip.ipn + "gettaska.php";

        StringRequest stringRequest = new StringRequest(Request.Method.POST, URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        handleResponse(response);
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                handleError(error);
            }
        }){
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("patient_id", username);
                return params;
            }
        };
                ;


        // Customize the retry policy
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                60000, DefaultRetryPolicy.DEFAULT_MAX_RETRIES, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        // Initialize the Volley request queue and add the request
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(stringRequest);
    }

    private void handleResponse(String response) {
        Log.d("JSON Response", response);

        try {
            JSONObject jsonObject = new JSONObject(response);
            boolean status = jsonObject.getBoolean("status");
            String message = jsonObject.getString("message");

            if (status) {
                // Clear the existing tasks list before populating it with new data
                tasks.clear();

                JSONArray dataArray = jsonObject.getJSONArray("data");
                JSONObject dataObject = dataArray.getJSONObject(0); // Assuming there's only one data object

                String patientId = dataObject.getString("patient_id");
                JSONArray selectedTitlesArray = dataObject.getJSONArray("selected_titles");

                for (int i = 0; i < selectedTitlesArray.length(); i++) {
                    String taskName = selectedTitlesArray.getString(i);
                    tasks.add(new Task(taskName));
                }

                // Notify the adapter that the data set has changed
                adapter.notifyDataSetChanged();
            } else {
                // Handle error message
                Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
            }
        } catch (JSONException e) {
            e.printStackTrace();
            Toast.makeText(this, "Error parsing JSON", Toast.LENGTH_SHORT).show();
        }

    }




    // Handle network request errors
    private void handleError(VolleyError error) {
        if (error instanceof TimeoutError) {
            Toast.makeText(this, "Request timed out. Check your internet connection.", Toast.LENGTH_SHORT).show();
        } else {
            System.out.println(error.toString().trim());
            Toast.makeText(this, error.toString().trim(), Toast.LENGTH_SHORT).show();
        }
    }

    private void sendSelectedTasks(final String selectedTasks) {
        String URL = ip.ipn + "patienttask.php";

        StringRequest stringRequest = new StringRequest(Request.Method.POST, URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        handleResponse1(response);
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                handleError(error);
            }
        }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("patient_id", username);
                params.put("selected_titles", selectedTasks);
                params.put("feedback", feed);
                return params;
            }
        };

        // Customize the retry policy
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                60000, DefaultRetryPolicy.DEFAULT_MAX_RETRIES, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        // Initialize the Volley request queue and add the request
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(stringRequest);
    }

    private void handleResponse1(String response) {
        Log.d("JSON Response", response);

        try {
            JSONObject jsonResponse = new JSONObject(response);

            // Check if the status is true
            boolean status = jsonResponse.getBoolean("status");
            if (status) {
                // Data inserted successfully
                String message = jsonResponse.getString("message");
                Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
                Intent it = new Intent(this, pat_home.class);
                it.putExtra("username",username);
                startActivity(it);
            } else {
                // Status is false, handle error or show message
                String errorMessage = jsonResponse.getString("message");
                Toast.makeText(this, errorMessage, Toast.LENGTH_SHORT).show();
            }
        } catch (JSONException e) {
            e.printStackTrace();
            Toast.makeText(this, "Error parsing JSON", Toast.LENGTH_SHORT).show();
        }
    }

}