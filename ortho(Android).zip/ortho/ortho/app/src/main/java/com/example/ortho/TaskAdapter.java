package com.example.ortho;
// TaskAdapter.java
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import java.util.List;

public class TaskAdapter extends ArrayAdapter<Task> {

    private Context context;
    private List<Task> tasks;

    public TaskAdapter(Context context, List<Task> tasks) {
        super(context, 0, tasks);
        this.context = context;
        this.tasks = tasks;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View listItemView = convertView;
        if (listItemView == null) {
            listItemView = LayoutInflater.from(context).inflate(R.layout.task_item, parent, false);
        }

        final Task currentTask = getItem(position);

        CheckBox checkBox = listItemView.findViewById(R.id.checkbox);
        checkBox.setText(currentTask.getName());
        checkBox.setChecked(currentTask.isChecked());
        checkBox.setOnCheckedChangeListener((buttonView, isChecked) -> currentTask.setChecked(isChecked));

        return listItemView;
    }
}
