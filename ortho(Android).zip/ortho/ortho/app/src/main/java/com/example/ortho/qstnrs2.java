package com.example.ortho;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.Window;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class qstnrs2 extends AppCompatActivity {

    private TextView q,t,t2,s,q8,q9,q91,q92,q93,q94,q95,q96,q97,q98,q99,q10,q9s0,q9s1,q9s2,q9s3,q9s4,q91st,q92st,q93st,q94st,q95st,q96st,q97st,q98st,q99st,q101,q102,q101st,q102st;
    private RadioButton q8c1,q8c2,q8c3,q8c4,q8c5;
    private SeekBar sk1,sk2,sk3,sk4,sk5,sk6,sk7,sk8,sk9,sk101,sk102;
    private int v1,v2,v3,v4,v5,v6,v7,v8,v9,v101,v102;
    private String username,lang,scr;
    private int score;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.qstnrs2);
        username = getIntent().getStringExtra("username");
        lang = getIntent().getStringExtra("lang");
        scr= getIntent().getStringExtra("score");


        score = Integer.parseInt(scr);
        //Toast.makeText(this, String.valueOf(score), Toast.LENGTH_SHORT).show();
        System.out.println(score);

        q=findViewById(R.id.textView71);
        t=findViewById(R.id.textView82);
        t2=findViewById(R.id.textView75);

        q8=findViewById(R.id.textView74);
        q8c1=findViewById(R.id.radioButton34);
        q8c2=findViewById(R.id.radioButton44);
        q8c3=findViewById(R.id.radioButton54);
        q8c4=findViewById(R.id.radioButton64);
        q8c5=findViewById(R.id.radioButton74);

        q9= findViewById(R.id.textView73);
        q9s0=findViewById(R.id.textView91);
        q9s1=findViewById(R.id.textView92);
        q9s2=findViewById(R.id.textView93);
        q9s3=findViewById(R.id.textView94);
        q9s4=findViewById(R.id.textView95);

        q91=findViewById(R.id.textView72);
        q91st = findViewById(R.id.textView101);
        sk1 = findViewById(R.id.seekBar3);
        sk1.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                q91st.setText("" + i);
                v1 = i;
            }
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        });

        q92=findViewById(R.id.textView77);
        q92st = findViewById(R.id.textView100);
        sk2 = findViewById(R.id.seekBar4);
        sk2.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                q92st.setText("" + i);
                v2 = i;
            }
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        });

        q93=findViewById(R.id.textView78);
        q93st = findViewById(R.id.textView99);
        sk3 = findViewById(R.id.seekBar52);
        sk3.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                q93st.setText("" + i);
                v3 = i;
            }
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        });

        q94=findViewById(R.id.textView76);
        q94st = findViewById(R.id.textView98);
        sk4 = findViewById(R.id.seekBar51);
        sk4.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                q94st.setText("" + i);
                v4 = i;
            }
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        });

        q95=findViewById(R.id.textView7615);
        q95st = findViewById(R.id.textView97);
        sk5 = findViewById(R.id.seekBar5115);
        sk5.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                q95st.setText("" + i);
                v5 = i;
            }
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        });

        q96=findViewById(R.id.textView7614);
        q96st = findViewById(R.id.textView96);
        sk6 = findViewById(R.id.seekBar5114);
        sk6.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                q96st.setText("" + i);
                v6 = i;
            }
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        });

        q97=findViewById(R.id.textView7613);
        q97st = findViewById(R.id.textView85);
        sk7 = findViewById(R.id.seekBar5113);
        sk7.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                q97st.setText("" + i);
                v7 = i;
            }
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        });

        q98=findViewById(R.id.textView7612);
        q98st = findViewById(R.id.textView84);
        sk8 = findViewById(R.id.seekBar5112);
        sk8.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                q98st.setText("" + i);
                v8 = i;
            }
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        });

        q99=findViewById(R.id.textView7611);
        q99st = findViewById(R.id.textView83);
        sk9 = findViewById(R.id.seekBar5111);
        sk9.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                q99st.setText("" + i);
                v9 = i;
            }
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        });

        q10= findViewById(R.id.textView102);

        q101= findViewById(R.id.textView782);
        q101st = findViewById(R.id.textView79);
        sk101 = findViewById(R.id.seekBar2);
        sk101.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                q101st.setText("" + i);
                v101 = i;
            }
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        });
        q102 = findViewById(R.id.textView7828);
        q102st = findViewById(R.id.textView799);
        sk102 = findViewById(R.id.seekBar29);
        sk102.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                q102st.setText("" + i);
                v102 = i;
            }
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        });

        s=findViewById(R.id.textView81);
        s.setOnClickListener(view -> {

            score=score+v1+v2+v3+v4+v5+v6+v7+v8+v9+v101+v102;
            if(q8c1.isChecked()){
                score=score+4;
            }
            else if(q8c2.isChecked()){
                score=score+3;
            }
            else if(q8c3.isChecked()){
                score=score+2;
            }
            else if(q8c4.isChecked()){
                score=score+1;
            }
            else if(q8c5.isChecked()){
                score=score+0;
            }
            Dialog myDialog = new Dialog(this);
            myDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
            //myDialog.setCancelable(false);
            myDialog.setContentView(R.layout.score);
            myDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            TextView sc=myDialog.findViewById(R.id.textView104);
            sc.setText(" "+score);
            myDialog.show();
            Button yes = myDialog.findViewById(R.id.button11);
            yes.setOnClickListener(view1 -> {
                sendSelectedTasks(String.valueOf(score));
            });


        });


        if(lang.equals("1")) {
            q.setText("கேள்விகள்");
            t.setText("பி: விளையாட்டு நடவடிக்கைகள்");
            t.setTextSize(16);
            q8.setText("8. நீங்கள் தொடர்ந்து பங்கேற்கக்கூடிய மிக உயர்ந்த அளவிலான செயல்பாடு எது?");
            q8c1.setText("கூடைப்பந்து அல்லது கால்பந்தில் ஜம்பிங் அல்லது பிவோட்டிங் போன்ற மிகவும் கடினமான நடவடிக்கைகள்");
            q8c2.setText("கடுமையான உடல் உழைப்பு, பனிச்சறுக்கு அல்லது டென்னிஸ் போன்ற கடுமையான நடவடிக்கைகள்");
            q8c3.setText("மிதமான உடல் உழைப்பு, ஓடுதல் அல்லது ஜாகிங் போன்ற மிதமான நடவடிக்கைகள்");
            q8c4.setText("நடைபயிற்சி, வீட்டு வேலைகள் அல்லது முற்றத்தில் வேலை செய்வது போன்ற இலகுவான செயல்பாடுகள்");
            q8c5.setText("முழங்கால் வலி காரணமாக மேற்கூறிய செயல்களில் எதையும் செய்ய முடியவில்லை");

            q9.setText("9. உங்கள் முழங்கால் உங்கள் திறனை எவ்வாறு பாதிக்கிறது:");
            q9s0.setText("முடியவில்லை செய்");
            q9s1.setText("மிகவும் கடினமான");
            q9s2.setText("மிதமாக கடினமான");
            q9s3.setText("குறைந்தபட்சம் கடினமான");
            q9s4.setText("கடினமாக இல்லை அனைத்தும்");

            q91.setText("A. படிக்கட்டுகளில் ஏறுங்கள்");
            q92.setText("B. படிக்கட்டுகளில் இறங்குங்கள்");
            q93.setText("C. உங்கள் முழங்காலின் முன் மண்டியிடவும்");
            q94.setText("D. குந்து");
            q95.setText("E. உங்கள் முழங்காலை வளைத்து உட்காரவும்");
            q96.setText("F. ஒரு நாற்காலியில் இருந்து எழுந்திரு");
            q97.setText("G. நேராக முன்னால் ஓடு");
            q98.setText("H. குதித்து உங்கள் சம்பந்தப்பட்ட காலில் இறங்கவும்");
            q99.setText("I. நிறுத்தி விரைவாக தொடங்குங்கள்");

            t2.setText("சி: செயல்பாடு");
            t2.setTextSize(18);

            q10.setText("10. உங்கள் முழங்காலின் செயல்பாட்டை 0 முதல் 10 வரையிலான அளவில் எப்படி மதிப்பிடுவீர்கள், 10 இயல்பானது, சிறப்பான செயல்பாடு மற்றும் 0 உங்கள் வழக்கமான தினசரி செயல்பாடுகளில் எதையும் செய்ய இயலாமையா?");
            q101.setText("A.உங்கள் முழங்கால் காயத்திற்கு முன் செயல்பாடு:");
            q102.setText("B.உங்கள் முழங்காலின் தற்போதைய செயல்பாடு:");

            q8c1.setTextSize(12);
            q8c2.setTextSize(12);
            q8c3.setTextSize(12);
            q8c4.setTextSize(12);
            q8c5.setTextSize(12);

        }

    }
    private void sendSelectedTasks(final String score) {
        String URL = ip.ipn + "points.php";

        StringRequest stringRequest = new StringRequest(Request.Method.POST, URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        handleResponse1(response);
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                handleError(error);
            }
        }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("patient_id", username);

                params.put("result", score);
                return params;
            }
        };

        // Customize the retry policy
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                60000, DefaultRetryPolicy.DEFAULT_MAX_RETRIES, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        // Initialize the Volley request queue and add the request
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(stringRequest);
    }

    private void handleResponse1(String response) {
        Log.d("JSON Response", response);

        try {
            JSONObject jsonResponse = new JSONObject(response);

            // Check if the status is true
            boolean status = jsonResponse.getBoolean("status");
            if (status) {
                // Data inserted successfully
                String message = jsonResponse.getString("message");
                Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
                Intent it = new Intent(this, pat_home.class);
                it.putExtra("username",username);
                startActivity(it);
            } else {
                // Status is false, handle error or show message
                String errorMessage = jsonResponse.getString("message");
                Toast.makeText(this, errorMessage, Toast.LENGTH_SHORT).show();
                Intent it = new Intent(this, pat_home.class);
                it.putExtra("username",username);
                startActivity(it);
            }
        } catch (JSONException e) {
            e.printStackTrace();
            Toast.makeText(this, "Error parsing JSON", Toast.LENGTH_SHORT).show();
        }
    }

    private void handleError(VolleyError error) {
        if (error instanceof TimeoutError) {
            Toast.makeText(this, "Request timed out. Check your internet connection.", Toast.LENGTH_SHORT).show();
        } else {
            System.out.println(error.toString().trim());
            Toast.makeText(this, error.toString().trim(), Toast.LENGTH_SHORT).show();
        }
    }
}