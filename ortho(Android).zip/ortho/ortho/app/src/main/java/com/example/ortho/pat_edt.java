package com.example.ortho;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class pat_edt extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.pat_edt);
    }
}