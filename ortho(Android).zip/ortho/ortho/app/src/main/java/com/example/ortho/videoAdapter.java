package com.example.ortho;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.ortho.R;
import com.example.ortho.Video;

import java.util.ArrayList;
import java.util.List;

public class videoAdapter extends BaseAdapter implements Filterable {

    private Context context;
    private List<Video> patientList;
    private List<Video> filteredList;

    public videoAdapter(Context context, List<Video> patients) {
        this.context = context;
        this.patientList = patients;
        this.filteredList = new ArrayList<>(patients);
    }

    @Override
    public int getCount() {
        return patientList.size();
    }

    @Override
    public Object getItem(int position) {
        return patientList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.video_item, parent, false);
            holder = new ViewHolder();
            holder.thumbnailImageView = convertView.findViewById(R.id.videoView);
            holder.nameTextView = convertView.findViewById(R.id.textView40);
            holder.ageTextView = convertView.findViewById(R.id.textView41);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        Video patient = patientList.get(position);
        if (patient != null && patient.getpath() != null) {
            System.out.println(patient.getpath());
            // Load and display the thumbnail using Glide library
            Glide.with(context)
                    .load(ip.ipn+patient.getpath())
                    .into(holder.thumbnailImageView);
        } else {
            Log.e("VideoAdapter", "Patient or thumbnail path is null");
        }

        holder.nameTextView.setText(patient.getName());
        holder.ageTextView.setText(patient.getage());

        return convertView;
    }

    static class ViewHolder {
        TextView nameTextView;
        TextView ageTextView;
        ImageView thumbnailImageView;
    }

    public void setFilteredList(List<Video> filteredList) {
        patientList = filteredList;
        notifyDataSetChanged();
    }

    @Override
    public Filter getFilter() {
        return new Filter() {
            @Override
            protected FilterResults performFiltering(CharSequence constraint) {
                FilterResults results = new FilterResults();
                List<Video> filtered = new ArrayList<>();
                if (constraint == null || constraint.length() == 0) {
                    // If constraint is null or empty, return the original list
                    filtered.addAll(patientList);
                } else {
                    String filterPattern = constraint.toString().toLowerCase().trim();
                    for (Video patient : patientList) {
                        // Filter the data based on the name containing the filter pattern
                        if (patient.getName().toLowerCase().contains(filterPattern)) {
                            filtered.add(patient);
                        }
                    }
                }
                results.values = filtered;
                results.count = filtered.size();
                return results;
            }

            @Override
            protected void publishResults(CharSequence constraint, FilterResults results) {
                filteredList.clear();
                filteredList.addAll((List<Video>) results.values);
                notifyDataSetChanged();
            }
        };
    }
}
