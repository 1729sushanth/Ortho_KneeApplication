package com.example.ortho;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CalendarView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class view_task extends AppCompatActivity {

    private TextView t1,t2;
    private CalendarView calendar;
    private String username;
    private LinearLayout lm,l1,l2,l3;
    private ListView listview;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.view_task);
        username = getIntent().getStringExtra("username");
        lm = findViewById(R.id.lm);
        l1=findViewById(R.id.l1);
        l2= findViewById(R.id.l2);
        l3=findViewById(R.id.l3);
        t1= findViewById(R.id.textView47);
        t2= findViewById(R.id.textView471);
        listview = findViewById(R.id.ListView);
        calendar = (CalendarView)
                findViewById(R.id.calendar);


        // Add Listener in calendar
        calendar.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
                            @Override

                            // In this Listener have one method
                            // and in this method we will
                            // get the value of DAYS, MONTH, YEARS
                            public void onSelectedDayChange(
                                    @NonNull CalendarView view,
                                    int year,
                                    int month,
                                    int dayOfMonth)
                            {

                                // Store the value of date with
                                // format in String type Variable
                                // Add 1 in month because month
                                // index is start with 0
                                String Date
                                        =  year+ "-"
                                        + (month + 1) + "-" + dayOfMonth;
                                sendLoginRequest(username,Date);
                                // set this date in TextView for Display
                                //date_view.setText(Date);
                            }
        });
    }

    private void sendLoginRequest(final String username,final String date) {
        String URL = ip.ipn+"viewtask.php";
        StringRequest stringRequest = new StringRequest(Request.Method.POST, URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        handleResponse(response,username);
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                handleError(error);
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                // Send the username and password as POST parameters
                Map<String, String> data = new HashMap<>();

                data.put("patient_id", username);
                data.put("date", date);



                return data;
            }
        };

        // Customize the retry policy
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                60000, DefaultRetryPolicy.DEFAULT_MAX_RETRIES, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        // Initialize the Volley request queue and add the request
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

    // Handle the JSON response
    private void handleResponse(String response, String username) {
        Log.d("JSON Response", response);

        try {
            JSONObject jsonObject = new JSONObject(response);
            boolean status = jsonObject.getBoolean("status");

            if (status) {
                // Type 2 response
                lm.setBackgroundColor(Color.parseColor("#54717E"));

                JSONArray dataArray = jsonObject.getJSONArray("data");
                JSONObject firstDataObject = dataArray.getJSONObject(0);

                // Set text of t1 to "result" field
                t1.setText(firstDataObject.getString("result"));

                // Set text of t2 to "feedback" field
                t2.setText(firstDataObject.getString("feedback"));

                // Extract and add elements of "selected_titles" to ListView
                JSONArray selectedTitlesArray = firstDataObject.getJSONArray("selected_titles");
                ArrayList<String> selectedTitlesList = new ArrayList<>();
                for (int i = 0; i < selectedTitlesArray.length(); i++) {
                    selectedTitlesList.add(selectedTitlesArray.getString(i));
                }
                ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, selectedTitlesList);
                listview.setAdapter(adapter);

                // Set layout parameters
                LinearLayout.LayoutParams params1 = new LinearLayout.LayoutParams(0, 0);
                l1.setLayoutParams(params1);
                LinearLayout.LayoutParams params2 = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                l2.setLayoutParams(params2);
                LinearLayout.LayoutParams params3 = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                params3.setMargins(0, 15, 0, 0); // Set margin between l2 and l3
                l3.setLayoutParams(params3);

            } else {
                // Type 1 response
                lm.setBackgroundColor(Color.WHITE);

                // Set layout parameters
                LinearLayout.LayoutParams params1 = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                l1.setLayoutParams(params1);
                LinearLayout.LayoutParams params2 = new LinearLayout.LayoutParams(0, 0);
                l2.setLayoutParams(params2);
                LinearLayout.LayoutParams params3 = new LinearLayout.LayoutParams(0, 0);
                l3.setLayoutParams(params3);

                Toast.makeText(this, jsonObject.getString("message"), Toast.LENGTH_SHORT).show();
            }
        } catch (JSONException e) {
            e.printStackTrace();
            Toast.makeText(this, "Error parsing JSON", Toast.LENGTH_SHORT).show();
        }
    }



    private void handleError(VolleyError error) {
        System.out.println("boooooo");
    }
}