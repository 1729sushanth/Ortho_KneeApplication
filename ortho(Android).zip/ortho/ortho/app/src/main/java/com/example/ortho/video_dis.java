package com.example.ortho;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.MediaController;
import android.widget.TextView;
import android.widget.VideoView;

public class video_dis extends AppCompatActivity {

    private VideoView videoView;
    String path,name,desc;
    private TextView t1,t2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.video_dis);
        path = getIntent().getStringExtra("path");
        name = getIntent().getStringExtra("name");
        desc = getIntent().getStringExtra("dscrp");
        t1=findViewById(R.id.textView42);
        t1.setText(name);
        t2= findViewById(R.id.textView43);
        t2.setText(desc);

        videoView=findViewById(R.id.videoView2);
        System.out.println(path);
        playVideo(ip.ipn+path);
    }

    private void playVideo(String videoPath) {
        MediaController mediaController = new MediaController(this);
        mediaController.setAnchorView(videoView);

        videoView.setMediaController(mediaController);
        videoView.setVideoPath(videoPath);
        videoView.requestFocus();
        videoView.start();
    }

}