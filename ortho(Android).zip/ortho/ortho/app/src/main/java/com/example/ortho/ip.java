package com.example.ortho;

public class ip {
    static String ipn ="http://172.23.21.86:80/ortho1/";
}
