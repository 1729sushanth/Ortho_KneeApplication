package com.example.ortho;

public class Video {

    private String name,path,age;



    public Video(String name,  String path,String age) {
        this.name = name;
        this.age = age;
        this.path = path;

    }

    public String getName() {
        return name;
    }
    public String getpath() {
        return path;
    }
    public String getage() {
        return age;
    }
}
