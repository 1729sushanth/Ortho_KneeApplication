package com.example.ortho;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.ImageDecoder;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

public class add_pat extends AppCompatActivity {
    private EditText epatid,egen,ename,eage,econt,ehght,ewght,esrg;
    private static final int CAMERA_GALLERY_REQUEST_CODE = 1001;
    private Intent lastActivityResultData;
    private String patid,gen,name,age,cont,hght,wght,srg,username;
    private Uri selectedImageUri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_pat);
        username = getIntent().getStringExtra("username");
        epatid=findViewById(R.id.textView16);
        ename=findViewById(R.id.textView17);
        eage=findViewById(R.id.textView19);
        egen=findViewById(R.id.textView20);
        econt=findViewById(R.id.textView18);
        ehght=findViewById(R.id.textView21);
        ewght=findViewById(R.id.textView22);
        esrg=findViewById(R.id.textView23);
        ImageView button4 = findViewById(R.id.imageView4);
        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openCameraOrGallery();
            }
        });

        Button bt = findViewById(R.id.button8);
        bt.setOnClickListener(view1 -> {
            patid = epatid.getText().toString().trim();
            name = ename.getText().toString().trim();
            age = eage.getText().toString().trim();
            gen = egen.getText().toString().trim();
            cont = econt.getText().toString().trim();
            hght = ehght.getText().toString().trim();
            wght = ewght.getText().toString().trim();
            srg = esrg.getText().toString().trim() + " 00:00:00";
            sendLoginRequest(username);
            if (selectedImageUri != null || lastActivityResultData != null) {
                try {
                    Bitmap bitmap;
                    if (selectedImageUri != null && selectedImageUri.toString().startsWith("content://")) {
                        ImageDecoder.Source source = ImageDecoder.createSource(getContentResolver(), selectedImageUri);
                        bitmap = ImageDecoder.decodeBitmap(source);
                    } else {
                        // Camera image captured
                        Bitmap photo = (Bitmap) lastActivityResultData.getExtras().get("data");
                        bitmap = photo;
                    }

                    String base64Image = convertBitmapToBase64(bitmap);
                    // Execute AsyncTask to send data to the server
                    new SendDataToServer().execute(patid, selectedImageUri != null ? selectedImageUri.toString() : "", base64Image);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            } else {
                Toast.makeText(add_pat.this, "Please select an image first", Toast.LENGTH_SHORT).show();
            }

            Intent intent = new Intent(this, doc_home.class);
            intent.putExtra("username", username);
            startActivity(intent);
            System.out.println("aaa "+username);
        });


    }

    private void sendLoginRequest(final String username) {
        String URL = ip.ipn+"add_pat.php";
        StringRequest stringRequest = new StringRequest(Request.Method.POST, URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        handleResponse(response,username);
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                handleError(error);
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                // Send the username and password as POST parameters
                Map<String, String> data = new HashMap<>();

                data.put("pat_id", patid);
                data.put("pat_name", name);
                data.put("pat_age", age);
                data.put("pat_gender", gen);
                data.put("pat_contact", cont);
                data.put("pat_height", hght);
                data.put("pat*_weight", wght);
                data.put("pat_dos", srg);

                return data;
            }
        };

        // Customize the retry policy
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                60000, DefaultRetryPolicy.DEFAULT_MAX_RETRIES, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        // Initialize the Volley request queue and add the request
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

    // Handle the JSON response
    private void handleResponse(String response,String username) {
        Log.d("JSON Response", response);

        // Handle your JSON response here without assuming a 'status' field
        // You can parse the response and handle success/failure accordingly
        try {
            // Example: Check if the response contains "success"
            if (response.toLowerCase().contains("true")) {
                Toast.makeText(this, "Sign Up successful", Toast.LENGTH_SHORT).show();


            } else {
                Toast.makeText(this, "Sign Up failed", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Error parsing JSON", Toast.LENGTH_SHORT).show();
        }
    }

    private void handleError(VolleyError error) {
        System.out.println("boooooo");
    }

    private String convertBitmapToBase64(Bitmap bitmap) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos);
        byte[] imageBytes = baos.toByteArray();
        return Base64.encodeToString(imageBytes, Base64.DEFAULT);
    }

    private void openCameraOrGallery() {
        Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        Intent galleryIntent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);

        // Create a chooser intent to allow the user to select between camera and gallery
        Intent chooser = Intent.createChooser(galleryIntent, "Select Image Source");
        chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[] { cameraIntent });

        startActivityForResult(chooser, CAMERA_GALLERY_REQUEST_CODE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CAMERA_GALLERY_REQUEST_CODE && resultCode == RESULT_OK) {
            if (data != null && data.getData() != null) {
                // Gallery image selected
                selectedImageUri = data.getData();
                ImageView imageView = findViewById(R.id.imageView4);
                imageView.setImageURI(selectedImageUri);
            } else if (data != null && data.getExtras() != null && data.getExtras().get("data") != null) {
                // Camera image captured
                lastActivityResultData = data; // Store the data
                Bitmap photo = (Bitmap) data.getExtras().get("data");
                ImageView imageView = findViewById(R.id.imageView4);
                imageView.setImageBitmap(photo);
            }
        }
    }

    private void handleCapturedImage(Bitmap photo) {
        // Handle the captured image here
        // For example, you can use it to upload to the server
        if (photo != null) {
            String base64Image = convertBitmapToBase64(photo);
            // Execute AsyncTask to send data to the server
            new SendDataToServer().execute(patid, selectedImageUri.toString(), base64Image);
        } else {
            Toast.makeText(add_pat.this, "Failed to capture image", Toast.LENGTH_SHORT).show();
        }
    }



    private class SendDataToServer extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... params) {
            try {
                String username = params[0];
                String imageUriString = params[1];
                String base64Image = params[2];
                System.out.println(base64Image);
                // Create a JSON object
                JSONObject jsonParams = new JSONObject();
                jsonParams.put("patient_id", username);


                jsonParams.put("base64image", base64Image);

                // Convert JSON object to string
                String jsonData = jsonParams.toString();

                URL url = new URL(ip.ipn+"upld.php");
                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();

                urlConnection.setRequestMethod("POST");
                urlConnection.setRequestProperty("Content-Type", "application/json;charset=UTF-8");
                urlConnection.setDoOutput(true);

                // Write JSON data to the server
                try (OutputStream os = urlConnection.getOutputStream()) {
                    byte[] input = jsonData.getBytes("utf-8");
                    os.write(input, 0, input.length);
                }

                // Get the response from the server
                InputStream inputStream = urlConnection.getInputStream();
                int responseCode = urlConnection.getResponseCode();
                System.out.println(responseCode);
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    return "Data inserted successfully";
                } else {
                    return "Failed to insert data";
                }
            } catch (IOException | JSONException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(String result) {
            if (result != null && result.equals("Data inserted successfully")) {
                Toast.makeText(add_pat.this, "success", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
