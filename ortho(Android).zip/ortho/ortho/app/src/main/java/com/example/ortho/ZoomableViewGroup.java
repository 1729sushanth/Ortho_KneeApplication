package com.example.ortho;
import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.widget.ImageView;
import android.widget.LinearLayout;

public class ZoomableViewGroup extends LinearLayout {
    private ScaleGestureDetector scaleGestureDetector;

    public ZoomableViewGroup(Context context) {
        super(context);
        init(context);
    }

    public ZoomableViewGroup(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    public ZoomableViewGroup(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context);
    }

    private void init(Context context) {
        scaleGestureDetector = new ScaleGestureDetector(context, new ScaleListener());
    }

    @Override
    public boolean onTouchEvent(MotionEvent ev) {
        scaleGestureDetector.onTouchEvent(ev);
        return true;
    }

    private class ScaleListener extends ScaleGestureDetector.SimpleOnScaleGestureListener {
        @Override
        public boolean onScale(ScaleGestureDetector detector) {
            float scaleFactor = detector.getScaleFactor();
            if (scaleFactor > 1) {
                // Zoom in
                // You can adjust the zoom factor according to your preference
                setScaleX(getScaleX() * scaleFactor);
                setScaleY(getScaleY() * scaleFactor);
            } else {
                // Zoom out
                // You can adjust the zoom factor according to your preference
                setScaleX(getScaleX() * scaleFactor);
                setScaleY(getScaleY() * scaleFactor);
            }
            return true;
        }
    }
}
