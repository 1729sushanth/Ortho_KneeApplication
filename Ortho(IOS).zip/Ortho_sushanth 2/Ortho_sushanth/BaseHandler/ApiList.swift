//
//  ApiList.swift
//  Ortho_sushanth
//
//  Created by SAIL on 29/01/24.
//

import Foundation

struct ApiList {
    static let baseURL = "http://172.23.21.86/ortho1/"
    static let doctorLogIn = baseURL+"doc_login.php?"
    static let patientLogIn = baseURL+"pat_login.php?"
    static let doctorProfile = baseURL+"doc_profile.php?"
    static let doctorEditProfile = baseURL+"edit_doc.php?"
    static let addpatientApi = baseURL + "add_pat.php?"
    static let patientListApi = baseURL + "pat_list.php?"
    static let allpatientListApi = baseURL + "allpat_list.php?"
    static let patientDetailsApi = baseURL + "pat_details.php?"
    static let addVideosApi = baseURL + "add_video.php"
    static let viewTaskApi = baseURL + "tasktitle.php?"
    static let addTaskApi = baseURL + "addtask.php"
    static let showVideoApi = baseURL + "retrivevideo.php?"
    static let editTaskApi = baseURL + "edittask.php"
    static let viewTaskCalendarApi = baseURL + "viewtask.php?"
    static let todaysTaskApi = baseURL + "gettask.php?"
    static let pointsApi = baseURL + "points.php?"
    static let patientTaskApi = baseURL + "patienttask.php?"
    static let editPatientApi = baseURL + "editpatientdetails.php"
    static let webApi = baseURL + "webdetails.php"
    static let profile = baseURL + "iosdp.php"
}
