//
//  DocProfileModel.swift
//  Ortho_sushanth
//
//  Created by SAIL on 02/02/24.
//

import Foundation
// MARK: - Welcome
struct DocProfileModel: Codable {
    let status: Bool
    let message: String
    let data: DocProfileData
}

// MARK: - DataClass
struct DocProfileData: Codable {
    let docID, pass, docName, docGender: String
    let docAge, docContact, docMail: String

    enum CodingKeys: String, CodingKey {
        case docID = "doc_id"
        case pass
        case docName = "doc_name"
        case docGender = "doc_gender"
        case docAge = "doc_age"
        case docContact = "doc_contact"
        case docMail = "doc_mail"
    }
}
