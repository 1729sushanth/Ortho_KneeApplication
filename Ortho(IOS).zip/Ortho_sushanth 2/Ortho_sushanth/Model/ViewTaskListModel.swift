//
//  ViewTaskListModel.swift
//  Ortho_sushanth
//
//  Created by SAIL on 09/02/24.
//

import Foundation
struct ViewTaskListModel: Codable {
    let status: Bool
    let message: String
    let data: [ViewTaskListData]
}

// MARK: - Datum
struct ViewTaskListData: Codable {
    let taskName: String

    enum CodingKeys: String, CodingKey {
        case taskName = "task_name"
    }
}
