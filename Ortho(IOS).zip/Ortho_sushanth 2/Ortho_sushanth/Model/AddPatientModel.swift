//
//  AddPatientModel.swift
//  Ortho_sushanth
//
//  Created by SAIL on 03/02/24.
//


import Foundation

// MARK: - Welcome
struct CommonPostResponseModel: Codable {
    let status: Bool
    let message: String
}
