//
//  PatientTodayTaskModel.swift
//  Ortho_sushanth
//
//  Created by SAIL on 24/02/24.
//

import Foundation

// MARK: - Welcome
struct PatientTodayTaskModel: Codable {
    let status: Bool
    let message: String
    let data: [PatientTodayTaskData]
}

// MARK: - Datum
struct PatientTodayTaskData: Codable {
    let patientID: String
    let selectedTitles: [String]

    enum CodingKeys: String, CodingKey {
        case patientID = "patient_id"
        case selectedTitles = "selected_titles"
    }
}
