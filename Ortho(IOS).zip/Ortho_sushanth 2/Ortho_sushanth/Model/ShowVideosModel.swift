//
//  ShowVideosModel.swift
//  Ortho_sushanth
//
//  Created by SAIL on 14/02/24.
//

import Foundation
struct ShowVideosModel: Codable {
    let status : Bool
    let message: String
    let data: [ShowVideosData]
}

// MARK: - Datum
struct ShowVideosData: Codable {
    let url, title, description: String
}
