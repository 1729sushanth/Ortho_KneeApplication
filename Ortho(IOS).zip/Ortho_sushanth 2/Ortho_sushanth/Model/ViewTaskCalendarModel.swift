//
//  ViewTaskCalendarModel.swift
//  Ortho_sushanth
//
//  Created by SAIL on 22/02/24.
//

import Foundation

struct ViewTaskCalendarModel: Codable {
    let status: Bool
    let message: String
    let data: [ViewTaskCalendarData]
}

// MARK: - Datum
struct ViewTaskCalendarData: Codable {
    let patientID: String
    let selectedTitles: [String]
    let feedback, result: String

    enum CodingKeys: String, CodingKey {
        case patientID = "patient_id"
        case selectedTitles = "selected_titles"
        case feedback, result
    }
}
