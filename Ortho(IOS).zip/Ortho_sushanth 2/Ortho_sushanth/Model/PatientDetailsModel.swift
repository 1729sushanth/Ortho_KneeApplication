//
//  PatientDetailsModel.swift
//  Ortho_sushanth
//
//  Created by SAIL on 06/02/24.
//

import Foundation
import Foundation

// MARK: - Welcome
struct PatientDetailsModel: Codable {
    let status: Bool
    let message: String
    let data: [PatientDetailsData]
}

// MARK: - Datum
struct PatientDetailsData: Codable {
    let patID, patName, patAge, patDOS: String
    let patContact: String
    let patGender: String
    let patHeight, weightcarry, dp, patWeight: String

    enum CodingKeys: String, CodingKey {
        case patID = "pat_id"
        case patName = "pat_name"
        case patAge = "pat_age"
        case patDOS = "pat_dos"
        case patContact = "pat_contact"
        case patGender = "pat_gender"
        case patHeight = "pat_height"
        case patWeight = "pat_weight"
        case dp
        case weightcarry = "weight_to_carry"
    }
}
