//
//  PatientListModel.swift
//  Ortho_sushanth
//
//  Created by SAIL on 05/02/24.
//

import Foundation
struct PatientListModel: Codable {
    let status: Bool
    let message: String
    let data: [PatientListData]
}

// MARK: - Datum
struct PatientListData: Codable {
    let patID, patName,dp, patAge: String

    enum CodingKeys: String, CodingKey {
        case patID = "pat_id"
        case patName = "pat_name"
        case patAge = "pat_age"
        case dp
    }
}
