//
//  PatientLogInModel.swift
//  Ortho_sushanth
//
//  Created by SAIL on 09/02/24.
//

import Foundation

// MARK: - Welcome

struct PatientLogInModel: Codable {
    let status: Bool
    let message: String
    let data: PatientLogInData
}

// MARK: - DataClass
struct PatientLogInData: Codable {
    let patID, patPass, patName, patContact: String
    let patAge, patGender, patHeight, patWeight: String
    let patDOS, weightToCarry: String

    enum CodingKeys: String, CodingKey {
        case patID = "pat_id"
        case patPass = "pat_pass"
        case patName = "pat_name"
        case patContact = "pat_contact"
        case patAge = "pat_age"
        case patGender = "pat_gender"
        case patHeight = "pat_height"
        case patWeight = "pat_weight"
        case patDOS = "pat_dos"
        case weightToCarry = "weight_to_carry"
    }
}
