//
//  PatientWebView.swift
//  Ortho_sushanth
//
//  Created by SAIL on 05/03/24.
//

import UIKit
import WebKit

class PatientWebView: BasicVC {

    @IBOutlet weak var webView: WKWebView!
    override func viewDidLoad() {
        super.viewDidLoad()

        let path = Bundle.main.path(forResource: "Meniscal repair", ofType: "pdf")
               let url = URL(fileURLWithPath: path!)
               let request = URLRequest(url: url)
               webView.load(request)
    }
    

    @IBAction func backBtn(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }

}
extension PatientWebView{
    func postApi(){
        self.startIndicator()
        APIHandler().postAPIValues(type: PatientTodayTaskModel.self, apiUrl: "\(ApiList.webApi)", method: "POST", formData: [:]) { Result in
            switch Result {
            case .success(let data):
                DispatchQueue.main.async { [self] in
                    self.stopIndicator()
                    showToast(data.message)
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async {
                    self.stopIndicator()
                    self.showAlert(title: "Failure", message: "Something Went Wrong", okActionHandler: {})
                }
            }
        }
    }
}
