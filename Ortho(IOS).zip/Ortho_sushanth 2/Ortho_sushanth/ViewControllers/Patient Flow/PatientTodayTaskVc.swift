//
//  PatientTodayTaskVc.swift
//  Ortho_sushanth
//
//  Created by SAIL on 16/02/24.
//

import UIKit

class PatientTodayTaskVc: BasicVC {

    @IBOutlet weak var taskTableView: UITableView!{
        didSet{
            self.taskTableView.delegate = self
            self.taskTableView.dataSource = self
            self.taskTableView.allowsMultipleSelection = true
        }
    }
  
    @IBOutlet weak var feedbackTextview: UITextView!
    @IBOutlet weak var yesButtonOutlet: UIButton!
    
    @IBOutlet weak var noButtonOutlet: UIButton!
    var getID = UserDefaultsManager.shared.getUserId() ?? ""
    var todayTaskData : [PatientTodayTaskData] = []
    var listDataAdded: [String] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        postApi()
        let cel = UINib(nibName: "TasksTableViewCell", bundle: nil)
       taskTableView.register(cel, forCellReuseIdentifier: "TasksTableViewCell")
        yesButtonOutlet.addTarget(self, action: #selector(buttonAction), for: .touchUpInside)
        noButtonOutlet.addTarget(self, action: #selector(buttonAction), for: .touchUpInside)
        feedbackTextview.delegate = self
       
        feedbackTextview.returnKeyType = .done
        feedbackTextview.resignFirstResponder()
        
        feedbackTextview.text = "Enter Any Comments"
        feedbackTextview.textColor = UIColor.lightGray
        
    }
    @objc func buttonAction(_ sender: UIButton) {
        if sender == yesButtonOutlet {
            yesButtonOutlet.setImage(UIImage(named: "Mark"), for: .normal)
            noButtonOutlet.setImage(UIImage(named: ""), for: .normal)
            yesButtonOutlet.setTitle("", for: .normal)
            noButtonOutlet.setTitle("No", for: .normal)
        } else if sender == noButtonOutlet {
            noButtonOutlet.setImage(UIImage(named: "UnMark"), for: .normal)
            yesButtonOutlet.setImage(UIImage(named: ""), for: .normal)
            yesButtonOutlet.setTitle("Yes", for: .normal)
            noButtonOutlet.setTitle("", for: .normal)
        }
    }

    @IBAction func submitButtonAct(_ sender: Any) {
        postApi1()
    }
    @IBAction func backBtn(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }

}
extension PatientTodayTaskVc : UITextViewDelegate{
    
    func textViewDidBeginEditing(_ textView: UITextView) {
        if feedbackTextview.textColor == UIColor.lightGray {
            feedbackTextview.text = nil
            feedbackTextview.textColor = UIColor.black
        }
    func textViewDidEndEditing(_ textView: UITextView) {
            if  feedbackTextview.text.isEmpty {
                feedbackTextview.text = "Enter Any Comments"
                feedbackTextview.textColor = UIColor.lightGray
            }
            
        }
        
    }
}
extension PatientTodayTaskVc: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        return ViewTaskList.count
        return todayTaskData.first?.selectedTitles.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TasksTableViewCell", for: indexPath) as! TasksTableViewCell
        cell.nameLbl.text = todayTaskData.first?.selectedTitles[indexPath.row]
        
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        guard let cell = tableView.cellForRow(at: indexPath) else { return }
        cell.accessoryType = .checkmark
        let selectedExercise = todayTaskData.first?.selectedTitles[indexPath.row]
        
        if !listDataAdded.contains(selectedExercise ?? "") {
            listDataAdded.append(selectedExercise ?? "")
            
        }
        print(selectedExercise ?? "")
    }

    func tableView(_ tableView: UITableView, didDeselectRowAt indexPath: IndexPath) {
        guard let cell = tableView.cellForRow(at: indexPath) else { return }
        cell.accessoryType = .none
        let deselectedExercise = todayTaskData.first?.selectedTitles[indexPath.row] ?? ""
        
        if let index = listDataAdded.firstIndex(of: deselectedExercise) {
            listDataAdded.remove(at: index)
            print("listDataAdded : \(listDataAdded)")
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 80
    }
}
extension PatientTodayTaskVc{
    func postApi(){
        self.startIndicator()
        let formData : [String : String] = ["patient_id": getID]
        APIHandler().postAPIValues(type: PatientTodayTaskModel.self, apiUrl: "\(ApiList.todaysTaskApi)", method: "POST", formData: formData) { Result in
            switch Result {
            case .success(let data):
                DispatchQueue.main.async { [self] in
                    self.stopIndicator()
                    showToast(data.message)
                    todayTaskData = data.data
                    taskTableView.reloadData()
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async {
                    self.stopIndicator()
                    self.showAlert(title: "Failure", message: "Something Went Wrong", okActionHandler: {})
                }
            }
        }
    }
    func postApi1(){
        self.startIndicator()
        let formData : [String : Any] = ["patient_id": getID,
                                            "selected_titles" : listDataAdded,
                                            "feedback" : feedbackTextview.text ?? ""]
        APIHandler().postAPIValues(type: CommonPostResponseModel.self, apiUrl: "\(ApiList.patientTaskApi)", method: "POST", formData: formData) { Result in
            switch Result {
            case .success(let data):
                DispatchQueue.main.async { [self] in
                    self.stopIndicator()
                    showToast(data.message)
                    if data.status{
                        self.showAlert(title: "Success", message: data.message,okActionHandler: {
                            self.pushToViewController(withIdentifier: "patientdashViewController")
                        })
                    }
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async {
                    self.stopIndicator()
                    self.showAlert(title: "Failure", message: "Something Went Wrong", okActionHandler: {})
                }
            }
        }
    }
}
