//
//  patientdashViewController.swift
//  Ortho_sushanth
//
//  Created by Sail L1 on 18/12/23.
//

import UIKit



class patientdashViewController: BasicVC {
    
    @IBOutlet weak var nameLabel: UILabel!
    
    var getID : String = UserDefaultsManager.shared.getUserId() ?? ""
    var patientDetails : [PatientDetailsData] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()

        postApi(PatientID : getID )
        
       
    }
    @IBAction func logOutButton(_ sender: Any) {
        self.showAlert(title: "Log Out", message: "Are you Sure?", okActionHandler: {
            self.pushToViewController(withIdentifier: "AdminVC")
        },cancelActionHandler: {})
    }
    
    @IBAction func whatsAction(_ sender: Any) {

        openWhatsAppChat(with: "9490715980", presentingViewController: self)
    }
    @IBAction func todayTaskButton(_ sender: Any) {
        self.pushToViewController(withIdentifier: "PatientTodayTaskVc")
       
    }
    @IBAction func patientProfileButton(_ sender: Any) {
        self.pushToViewController(withIdentifier: "PatientProfileVC")
       
    }
    @IBAction func webViewButton(_ sender: Any) {
        self.pushToViewController(withIdentifier: "PatientWebView")
       
    }
    @IBAction func dailyProgressButton(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "viewtaskViewController") as! viewtaskViewController
        vc.patientFlow = true
        self.navigationController?.pushViewController(vc, animated: true)
    }
    @IBAction func viewVideoButton(_ sender: Any) {
        self.pushToViewController(withIdentifier: "ProtocolsViewController")
       
    }
    @IBAction func questionButton(_ sender: Any) {
        let alertController = UIAlertController(title: nil, message: "Choose Language", preferredStyle: .alert)

        // Add Tamil button
        let tamilAction = UIAlertAction(title: "தமிழ்", style: .default) { (_) in
            self.pushToViewController(withIdentifier: "QTamilPartOneVC")
        }
        alertController.addAction(tamilAction)

        // Add English button
        let englishAction = UIAlertAction(title: "English", style: .default) { (_) in
            self.pushToViewController(withIdentifier: "QuestionariesPartOneVC")
        }
        alertController.addAction(englishAction)

        present(alertController, animated: true, completion: nil)
    }
}
extension patientdashViewController{
    func postApi(PatientID : String ){
        let formDatas : [String : Any] = ["pat_id": PatientID]
        self.startIndicator()
        APIHandler().postAPIValues(type: PatientDetailsModel.self, apiUrl: ApiList.patientDetailsApi  , method: "POST", formData: formDatas) { Result in
            switch Result {
            case .success(let data):
                DispatchQueue.main.async {[self] in
                    self.stopIndicator()
                    if data.status{
                        self.patientDetails = data.data
                        nameLabel.text = "Welcome \(patientDetails.first?.patName ?? "")!"
                    }
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async {
                    self.stopIndicator()
                    self.showAlert(title: "Failure", message: "Something Went Wrong", okActionHandler: {})
                }
            }
        }
    }
}

