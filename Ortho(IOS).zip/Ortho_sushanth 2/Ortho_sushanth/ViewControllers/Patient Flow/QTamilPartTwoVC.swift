//
//  QTamilPartTwoVC.swift
//  Ortho_sushanth
//
//  Created by SAIL on 08/03/24.
//

import UIKit

class QTamilPartTwoVC: BasicVC {
    
    @IBOutlet var qEightAnswerButtons: [UIButton]!
    @IBOutlet var qNineAAnswerButtons: [UIButton]!
    @IBOutlet var qNineBAnswerButtons: [UIButton]!
    @IBOutlet var qNineCAnswerButtons: [UIButton]!
    @IBOutlet var qNineDAnswerButtons: [UIButton]!
    @IBOutlet var qNineEAnswerButtons: [UIButton]!
    @IBOutlet var qNineFAnswerButtons: [UIButton]!
    @IBOutlet var qNineGAnswerButtons: [UIButton]!
    @IBOutlet var qNineHAnswerButtons: [UIButton]!
    @IBOutlet var qNineIAnswerButtons: [UIButton]!
    @IBOutlet var qTenAAnswerButtons: [UIButton]!
    @IBOutlet var qTenBAnswerButtons: [UIButton]!
    var getID = UserDefaultsManager.shared.getUserId() ?? ""
    
    var totalSum : Int = 0
    var marksData: [(String, String)] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Set up actions for all button arrays
        setupButtonActions(for: qEightAnswerButtons, identifier: "qEightAnswer")
        setupButtonActions(for: qNineAAnswerButtons, identifier: "qNineAAnswer")
        setupButtonActions(for: qNineBAnswerButtons, identifier: "qNineBAnswer")
        setupButtonActions(for: qNineCAnswerButtons, identifier: "qNineCAnswer")
        setupButtonActions(for: qNineDAnswerButtons, identifier: "qNineDAnswer")
        setupButtonActions(for: qNineEAnswerButtons, identifier: "qNineEAnswer")
        setupButtonActions(for: qNineFAnswerButtons, identifier: "qNineFAnswer")
        setupButtonActions(for: qNineGAnswerButtons, identifier: "qNineGAnswer")
        setupButtonActions(for: qNineHAnswerButtons, identifier: "qNineHAnswer")
        setupButtonActions(for: qNineIAnswerButtons, identifier: "qNineIAnswer")
        setupButtonActions(for: qTenAAnswerButtons, identifier: "qTenAAnswer")
        setupButtonActions(for: qTenBAnswerButtons, identifier: "qTenBAnswer")
    }
    
    @IBAction func backBtn(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func submitButton(_ sender: Any) {
        // Calculate the total sum of the answers
        for (_, answer) in marksData {
            if let intValue = Int(answer) {
                totalSum += intValue
            }
        }
     
        postApi()
    
        showToast("The Total Marks is \(totalSum)")
        print("Total Sum: \(totalSum)")
    }

    
    func setupButtonActions(for buttons: [UIButton], identifier: String) {
        for button in buttons {
            button.addTarget(self, action: #selector(buttonTapped(_:)), for: .touchUpInside)
            button.tag = buttons.firstIndex(of: button) ?? 0 // Set button's tag to its index in the array
            button.accessibilityIdentifier = identifier // Set button's accessibilityIdentifier to the identifier
        }
    }
    
    @objc func buttonTapped(_ sender: UIButton) {
        if let buttonTitle = sender.titleLabel?.text, let identifier = sender.accessibilityIdentifier {
            // Update the UI to highlight the selected button and show a checkmark icon
            for button in sender.superview?.subviews as? [UIButton] ?? [] {
                button.isSelected = (button == sender)
                let imageName = button.isSelected ? "checkmark.circle.fill" : ""
                button.setImage(UIImage(systemName: imageName), for: .normal)
            }
            marksData.removeAll { $0.0 == identifier } // Remove any previous entry for the same button set
            marksData.append((identifier, buttonTitle))
            print("marksData : \(marksData)")
        }
    }
}
extension QTamilPartTwoVC{
    
    func postApi(){
        
        self.startIndicator()
        let formData : [String : String] = ["patient_id": getID,
                                            "result": "\(totalSum)"]
        APIHandler().postAPIValues(type: CommonPostResponseModel.self, apiUrl: "\(ApiList.pointsApi)", method: "POST", formData: formData) { Result in
            switch Result {
            case .success(let data):
                DispatchQueue.main.async { [self] in
                    self.stopIndicator()
                    showToast(data.message)
                    showAlert(title: "Total = \(totalSum)", message: data.message,okActionHandler: {
                        self.pushToViewController(withIdentifier: "patientdashViewController")
                    })
                    
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async {
                    self.stopIndicator()
                    self.showAlert(title: "Failure", message: "Something Went Wrong", okActionHandler: {})
                }
            }
        }
    }
}
