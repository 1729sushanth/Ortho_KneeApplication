//
//  QTamilPartOneVC.swift
//  Ortho_sushanth
//
//  Created by SAIL on 08/03/24.
//

import UIKit

class QTamilPartOneVC: BasicVC {
    
    @IBOutlet var qOneAnswerButtons: [UIButton]!
    @IBOutlet var qTwoAnswerButtons: [UIButton]!
    @IBOutlet var qThreeAnswerButtons: [UIButton]!
    @IBOutlet var qFourAnswerButtons: [UIButton]!
    @IBOutlet var qFiveAnswerButtons: [UIButton]!
    @IBOutlet var qSixAnswerButtons: [UIButton]!
    @IBOutlet var qSevenAnswerButtons: [UIButton]!
    
    var marksData: [(String, String)] = [] // Use a tuple array to maintain order
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Set up actions for all button arrays
        setupButtonActions(for: qOneAnswerButtons, identifier: "qOneAnswer")
        setupButtonActions(for: qTwoAnswerButtons, identifier: "qTwoAnswer")
        setupButtonActions(for: qThreeAnswerButtons, identifier: "qThreeAnswer")
        setupButtonActions(for: qFourAnswerButtons, identifier: "qFourAnswer")
        setupButtonActions(for: qFiveAnswerButtons, identifier: "qFiveAnswer")
        setupButtonActions(for: qSixAnswerButtons, identifier: "qSixAnswer")
        setupButtonActions(for: qSevenAnswerButtons, identifier: "qSevenAnswer")
    }
    
    @IBAction func backBtn(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func nextButton(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
            if let viewController = storyboard.instantiateViewController(withIdentifier: "QTamilPartTwoVC") as? QTamilPartTwoVC {
                viewController.marksData = self.marksData
                navigationController?.pushViewController(viewController, animated: true)
            }
    }
    
    func setupButtonActions(for buttons: [UIButton], identifier: String) {
        for button in buttons {
            button.addTarget(self, action: #selector(buttonTapped(_:)), for: .touchUpInside)
            button.tag = buttons.firstIndex(of: button) ?? 0 // Set button's tag to its index in the array
            button.accessibilityIdentifier = identifier
        }
    }

    
    @objc func buttonTapped(_ sender: UIButton) {
        if let buttonTitle = sender.titleLabel?.text, let identifier = sender.accessibilityIdentifier {
            if identifier == "qSixAnswer" {
                // Update the UI for qSixAnswerButtons
                for button in qSixAnswerButtons {
                    button.isSelected = (button == sender)
                    let imageName = button.isSelected ? "checkmark.circle.fill" : ""
                    button.setImage(UIImage(systemName: imageName), for: .normal)
                }
                
                marksData.removeAll { $0.0 == "qSixAnswer" }
                marksData.append(("qSixAnswer", buttonTitle))
                print("marksData : \(marksData)")
                
                // Deselect other buttons in qSixAnswerButtons
                for button in qSixAnswerButtons {
                    if button != sender {
                        button.isSelected = false
                        button.setImage(nil, for: .normal)
                    }
                }
            } else {
                for buttons in [qOneAnswerButtons, qTwoAnswerButtons, qThreeAnswerButtons, qFourAnswerButtons, qFiveAnswerButtons, qSevenAnswerButtons] {
                    if let buttonIndex = buttons?.firstIndex(of: sender) {
                        for button in buttons! {
                            button.isSelected = (button == sender)
                            let imageName = button.isSelected ? "checkmark.circle.fill" : ""
                            button.setImage(UIImage(systemName: imageName), for: .normal)
                        }
                        marksData.removeAll { $0.0 == identifier }
                        marksData.append((identifier, buttonTitle))
                        print("marksData : \(marksData)")
                        break
                    }
                }
            }
        }
    }



}
