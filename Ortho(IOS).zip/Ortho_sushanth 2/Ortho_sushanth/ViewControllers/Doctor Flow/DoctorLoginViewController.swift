//
//  DoctorLoginViewController.swift
//  Ortho_sushanth
//
//  Created by Sail L1 on 15/12/23.
//

import UIKit

class DoctorLoginViewController: BasicVC {
    
    @IBOutlet weak var titleLoginLabel: UILabel!
    @IBOutlet weak var docIDTxt: UITextField!
    @IBOutlet weak var docPasswordTxt: UITextField!
    
    @IBOutlet weak var subView: UIView!

    var doctorLogin : DoctorLogInModel!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        if UserDefaultsManager.shared.getUserName() == "Patient" {
            docIDTxt.placeholder = "Candidate ID"
            titleLoginLabel.text = "Candidate LogIn"
        }
        
        subView.layer.cornerRadius = 10
    }
    
    @IBAction func loginBtn(_ sender: Any) {
        getApi()
//        if UserDefaultsManager.shared.getUserName() == "Doctor"{
//           
//          
//        }else{
//            pushToViewController(withIdentifier: "patientdashViewController")
//        }
            
    }
    @IBAction func backBtn(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
}

extension DoctorLoginViewController{
    func getApi(){
        
        self.startIndicator()
        if UserDefaultsManager.shared.getUserName() == "Doctor"{
            
            APIHandler().getAPIValues(type: DoctorLogInModel.self, apiUrl: "\(ApiList.doctorLogIn)doc_id=\(docIDTxt.text ?? "")&doc_pass=\(docPasswordTxt.text ?? "")"  , method: "GET") { Result in
                switch Result {
                case .success(let data):
                    DispatchQueue.main.async {
                        self.doctorLogin = data
                        self.stopIndicator()
                        UserDefaultsManager.shared.saveUserId(self.docIDTxt.text ?? "")
                        self.pushToViewController(withIdentifier: "DashBoardViewController")
                    }
                case .failure(let error):
                    print(error)
                    DispatchQueue.main.async {
                        self.stopIndicator()
                        self.showAlert(title: "Failure", message: "Something Went Wrong", okActionHandler: {})
                    }
                }
            }
        }else if UserDefaultsManager.shared.getUserName() == "Patient" {           APIHandler().getAPIValues(type: PatientLogInModel.self, apiUrl: "\(ApiList.patientLogIn)pat_id=\(docIDTxt.text ?? "")&pat_pass=\(docPasswordTxt.text ?? "")"  , method: "GET") { Result in
            switch Result {
            case .success(let data):
                DispatchQueue.main.async {
//                    self.doctorLogin = data
                    self.stopIndicator()
                    UserDefaultsManager.shared.saveUserId(self.docIDTxt.text ?? "")
                    self.pushToViewController(withIdentifier: "patientdashViewController")
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async {
                    self.stopIndicator()
                    self.showAlert(title: "Failure", message: "Something Went Wrong", okActionHandler: {})
                }
            }
        }
        }
    }
}

