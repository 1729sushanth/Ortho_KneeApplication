//
//  viewtaskViewController.swift
//  Ortho_sushanth
//
//  Created by Sail L1 on 18/12/23.
//

import UIKit

class viewtaskViewController: BasicVC {
    
    @IBOutlet weak var taskTableView: UITableView!
    @IBOutlet weak var noDataView: UIView!
    @IBOutlet weak var calendarView: UIDatePicker!
    @IBOutlet weak var feedBackView: UIView!
    @IBOutlet weak var scoreLabel: UILabel!
    @IBOutlet weak var feedbacklabel : UILabel!
    var patientFlow = false
    var getID = ""
    var calendarData : [ViewTaskCalendarData] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        if patientFlow{
            getID = UserDefaultsManager.shared.getUserId() ?? ""
        }else{
            getID = UserDefaultsManager.shared.getPatientnamekey() ?? ""
        }

        let cel = UINib(nibName: "TasksTableViewCell", bundle: nil)
        taskTableView.register(cel, forCellReuseIdentifier: "TasksTableViewCell")
        self.taskTableView.delegate = self
        self.taskTableView.dataSource = self
        calendarView.addTarget(self, action: #selector(datePickerValueChanged(_:)), for: .valueChanged)
    
    }

    @IBAction func backBtn(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }

    @objc func datePickerValueChanged(_ sender: UIDatePicker) {
        // Check if the selected date is present in the dateContain array
        let selectedDate = sender.date
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        let dateString = dateFormatter.string(from: selectedDate)
postApi(selectedDate: dateString)

    }

}

extension viewtaskViewController{
    func postApi(selectedDate: String){
        
        self.startIndicator()
        let formData : [String : Any] = ["patient_id": getID,
                                         "date" : selectedDate]
        APIHandler().postAPIValues(type: ViewTaskCalendarModel.self, apiUrl: "\(ApiList.viewTaskCalendarApi)", method: "POST", formData: formData) { Result in
            switch Result {
            case .success(let data):
                DispatchQueue.main.async { [self] in
                    self.stopIndicator()
                    self.calendarData = data.data
                    self.showToast(data.message)
                    self.taskTableView.reloadData()
                   
                    if data.status{
                        self.noDataView.isHidden = true
                        if calendarData.first?.result == "" {
                            self.scoreLabel.text = "Result : 0"
                            scoreLabel.isHidden = true
                        }else{
                            self.scoreLabel.text = "Result : \(self.calendarData.first?.result ?? "")"
                        }
                        
                        self.feedbacklabel.text = "FeedBack : \(self.calendarData.first?.feedback ?? "")"
                        
                    }else{
                        self.noDataView.isHidden = false
                        self.scoreLabel.text = "Result : 0"
                        self.feedbacklabel.text = "FeedBack : 0"
                        
                        self.showToast(data.message)
                    }
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async {
                    self.stopIndicator()
                    self.showAlert(title: "Failure", message: "Something Went Wrong", okActionHandler: {})
                }
            }
        }
    }
}

extension viewtaskViewController: UITableViewDelegate, UITableViewDataSource {

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        print("calendarData.first?.selectedTitles.count : \(String(describing: calendarData.first?.selectedTitles.count))")
        return calendarData.first?.selectedTitles.count ?? 0
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TasksTableViewCell", for: indexPath) as! TasksTableViewCell
        cell.nameLbl.text =  calendarData.first?.selectedTitles[indexPath.row]
        return cell
    }

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60
    }
    


}
