//
//  editpatientViewController.swift
//  Ortho_sushanth
//
//  Created by Sail L1 on 18/12/23.
//

import UIKit

class editpatientViewController: BasicVC {
    
    @IBOutlet weak var nameTxt: UITextField!
    
    @IBOutlet weak var idTxt: UITextField!
    
    @IBOutlet weak var contactTxt: UITextField!
    
    @IBOutlet weak var ageTxt: UITextField!
    
    @IBOutlet weak var genderTxt: UITextField!
    
    @IBOutlet weak var heightTxt: UITextField!
    
    @IBOutlet weak var weightTxt: UITextField!
    
    @IBOutlet weak var dosTxt: UITextField!
    
    @IBOutlet weak var profileImage: UIImageView!
    
    var patientIDVariable : String = ""
    var patientDetails : [PatientDetailsData] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        postApi(PatientID: patientIDVariable)
    }
    
    @IBAction func backBtn(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    
    @IBAction func editpatient(_ sender: Any) {
        let storyBoard: UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
                    let vc = storyBoard.instantiateViewController(withIdentifier: "EditsaveViewController") as! EditsaveViewController
        vc.patientIDVariable = patientIDVariable
                    self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func ontask(_ sender: Any) {
        let storyBoard: UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
                    let vc = storyBoard.instantiateViewController(withIdentifier: "viewtaskViewController") as! viewtaskViewController
                    
                    self.navigationController?.pushViewController(vc, animated: true)
    }
}
    
extension editpatientViewController{
    func postApi(PatientID : String ){
        let formDatas : [String : Any] = ["pat_id": PatientID]
        self.startIndicator()
        APIHandler().postAPIValues(type: PatientDetailsModel.self, apiUrl: ApiList.patientDetailsApi  , method: "POST", formData: formDatas) { Result in
            switch Result {
            case .success(let data):
                DispatchQueue.main.async {[self] in
                    self.stopIndicator()
                    if data.status{
                        self.patientDetails = data.data
                        idTxt.text = patientDetails.first?.patID
                        nameTxt.text = patientDetails.first?.patName
                        contactTxt.text = patientDetails.first?.patContact
                        ageTxt.text = patientDetails.first?.patAge
                        genderTxt.text = patientDetails.first?.patGender
                        heightTxt.text = patientDetails.first?.patHeight
                        weightTxt.text = patientDetails.first?.patWeight
                        dosTxt.text = patientDetails.first?.patDOS
                        if let imageData = Data(base64Encoded: "\(patientDetails.first?.dp ?? "")", options: .ignoreUnknownCharacters) {
                         print("imageData : \(imageData)")
                            if let image = UIImage(data: imageData) {
                                profileImage.image = image
                            } else {
                                profileImage.image = UIImage(named: "Image") // Use a default image if conversion fails
                            }
                        } else {
                           profileImage.image = UIImage(named: "Image") // Use a default image if conversion fails
                        }

                        
                    }
                    
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async {
                    self.stopIndicator()
                    self.showAlert(title: "Failure", message: "Something Went Wrong", okActionHandler: {})
                }
            }
        }
    }
}

