//
//  DoctorEditProfileVC.swift
//  Ortho_sushanth
//
//  Created by SAIL on 22/02/24.
//

import UIKit

class DoctorEditProfileVC: BasicVC {

    @IBOutlet weak var doctorNameTextField: UITextField!
    
    @IBOutlet weak var doctorIdLabel: UILabel!
    @IBOutlet weak var AgeTextField: UITextField!
    @IBOutlet weak var genderTextField: UITextField!
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var contactTextField: UITextField!
    var getID = UserDefaultsManager.shared.getUserId() ?? ""
   
    
    override func viewDidLoad() {
        super.viewDidLoad()
      
        doctorIdLabel.text = getID
    }
        
    func postApi(){
        
        self.startIndicator()
        let formData : [String : String] = ["doc_id": getID,
                                            "doc_name": self.doctorNameTextField.text ?? "",
                                            "doc_gender": self.genderTextField.text ?? "",
                                            "doc_age": self.AgeTextField.text ?? "",
                                            "doc_contact": self.contactTextField.text ?? "",
                                            "doc_mail": self.emailTextField.text ?? "",]
        APIHandler().postAPIValues(type: CommonPostResponseModel.self, apiUrl: "\(ApiList.doctorEditProfile)", method: "POST", formData: formData) { Result in
            switch Result {
            case .success(let data):
                DispatchQueue.main.async {
                    self.stopIndicator()
                    self.showAlert(title: "Success", message: data.message,okActionHandler: {
                        self.pushToViewController(withIdentifier: "DashBoardViewController")
                    })
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async {
                    self.stopIndicator()
                    self.showAlert(title: "Failure", message: "Something Went Wrong", okActionHandler: {})
                }
            }
        }
    }
    
    @IBAction func backBtn(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    @IBAction func saveButton(_ sender: Any) {
        if doctorNameTextField.text?.isEmpty == true || genderTextField.text?.isEmpty == true ||  AgeTextField.text?.isEmpty == true ||  contactTextField.text?.isEmpty == true ||   emailTextField.text?.isEmpty == true{
            showToast("All field is required")
        }else{
            postApi()
        }
        
    }
}


