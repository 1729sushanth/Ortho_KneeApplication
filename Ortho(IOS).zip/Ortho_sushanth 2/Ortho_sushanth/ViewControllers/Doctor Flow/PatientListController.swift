//
//  PatientListController.swift
//  Ortho_sushanth
//
//  Created by Sail L1 on 18/12/23.
//

import UIKit

class PatientListController: BasicVC {
    
    @IBOutlet weak var patientListTable: UITableView!
    @IBOutlet weak var searchBarOutlet: UISearchBar! {
           didSet {
               searchBarOutlet.delegate = self
           }
       }
    var patientList : [PatientListData] = []
    var filteredPatientListData: [PatientListData] = []
       

    override func viewDidLoad() {
        super.viewDidLoad()
        getApi()
        patientListTable.delegate = self
        patientListTable.dataSource = self
        
       let cell = UINib(nibName: "RecentPatientCell", bundle: nil)
        patientListTable.register(cell, forCellReuseIdentifier: "RecentPatientCell")
    }
    

    @IBAction func backBtn(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
}


extension PatientListController{
    func getApi(){
        self.startIndicator()
        APIHandler().getAPIValues(type: PatientListModel.self, apiUrl: ApiList.allpatientListApi  , method: "GET") { Result in
            switch Result {
            case .success(let data):
                DispatchQueue.main.async {
                    self.patientList = data.data
                    self.filteredPatientListData = data.data
                    self.patientListTable.reloadData()
                    self.stopIndicator()
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async {
                    self.stopIndicator()
                    self.showAlert(title: "Failure", message: "Something Went Wrong", okActionHandler: {})
                }
            }
        }
    }
       
}
extension PatientListController: UITableViewDelegate,UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return filteredPatientListData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "RecentPatientCell", for: indexPath) as! RecentPatientCell
        
        cell.nameLbl.text = filteredPatientListData[indexPath.row].patName
        cell.idLabel.text = filteredPatientListData[indexPath.row].patID
        cell.ageLabel.text = filteredPatientListData[indexPath.row].patAge

        // Convert Base64 string to Data
        if let imageData = Data(base64Encoded: filteredPatientListData[indexPath.row].dp, options: .ignoreUnknownCharacters) {
         print("imageData : \(imageData)")
            if let image = UIImage(data: imageData) {
                cell.profileImage.image = image
            } else {
                cell.profileImage.image = UIImage(named: "Image") // Use a default image if conversion fails
            }
        } else {
            cell.profileImage.image = UIImage(named: "Image") // Use a default image if conversion fails
        }

        return cell
    }

    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100.0
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let storyBoard: UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "editpatientViewController") as! editpatientViewController
        UserDefaultsManager.shared.savePatientnameKey(filteredPatientListData[indexPath.row].patID)
        vc.patientIDVariable = filteredPatientListData[indexPath.row].patID
        self.navigationController?.pushViewController(vc, animated: true)
    }
}
extension PatientListController: UISearchBarDelegate {
    
func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        if searchText.isEmpty {
            filteredPatientListData = patientList 
        } else {
            filteredPatientListData = patientList.filter { $0.patName.lowercased().contains(searchText.lowercased()) || $0.patID.lowercased().contains(searchText.lowercased()) }
        }
    patientListTable.reloadData()
    }

}
