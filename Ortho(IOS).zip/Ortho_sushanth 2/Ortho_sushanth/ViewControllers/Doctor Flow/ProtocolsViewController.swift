//
//  ProtocolsViewController.swift
//  Ortho_sushanth
//
//  Created by Sail L1 on 30/12/23.
//

import UIKit
import AVKit
import AVFoundation
import SDWebImage

class ProtocolsViewController: BasicVC, AVPlayerViewControllerDelegate {

    @IBOutlet weak var videosTable: UITableView!
    var videosListData: [ShowVideosData] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        getApi()
        videosTable.delegate = self
        videosTable.dataSource = self
        let cell = UINib(nibName: "ProtocolVideoCell", bundle: nil)
        videosTable.register(cell, forCellReuseIdentifier: "cell")
    }
    @IBAction func backBtn(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }

    func getApi() {
        startIndicator()
        APIHandler().getAPIValues(type: ShowVideosModel.self, apiUrl: ApiList.showVideoApi, method: "GET") { result in
            switch result {
            case .success(let data):
                DispatchQueue.main.async {
                    self.videosListData = data.data
                    self.videosTable.reloadData()
                    self.stopIndicator()
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async {
                    self.stopIndicator()
                    self.showAlert(title: "Failure", message: "Something Went Wrong", okActionHandler: {})
                }
            }
        }
    }

    func fetchThumbnail(for videoURL: String, completion: @escaping (UIImage?) -> Void) {
        guard let url = URL(string: videoURL) else {
            completion(nil)
            return
        }
        
        let asset = AVAsset(url: url)
        let generator = AVAssetImageGenerator(asset: asset)
        generator.appliesPreferredTrackTransform = true
        
        let time = CMTimeMakeWithSeconds(0.5, preferredTimescale: 600)
        do {
            let cgImage = try generator.copyCGImage(at: time, actualTime: nil)
            let thumbnail = UIImage(cgImage: cgImage)
            completion(thumbnail)
        } catch {
            print("Error generating thumbnail: \(error.localizedDescription)")
            completion(nil)
        }
    }

}

extension ProtocolsViewController: UITableViewDelegate, UITableViewDataSource {

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return videosListData.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! ProtocolVideoCell
        cell.nameLabel.text = videosListData[indexPath.row].title
        cell.descriptionLabel.text = videosListData[indexPath.row].description
        
        let videoURLString = ApiList.baseURL + videosListData[indexPath.row].url
        guard let videoURL = URL(string: ApiList.baseURL + videosListData[indexPath.row].url) else {
            // Invalid URL, handle error or provide placeholder image
            cell.Videoimage.image = UIImage(named: "Image")
            return cell
        }
        fetchThumbnail(for: videoURLString) { thumbnailImage in
            DispatchQueue.main.async {
                cell.Videoimage.image = thumbnailImage
            }
        }
        return cell
    }

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 200.0
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        
        let selectedVideo = videosListData[indexPath.row]
        guard let viewVideoVC = storyboard?.instantiateViewController(withIdentifier: "ViewVideoVc") as? ViewVideoVc else {
            return
        }
        viewVideoVC.modalPresentationStyle = .fullScreen
        viewVideoVC.name = selectedVideo.title
        viewVideoVC.descriptionName = selectedVideo.description
        viewVideoVC.videoData = ApiList.baseURL + selectedVideo.url
        navigationController?.pushViewController(viewVideoVC, animated: true)
    }
}

