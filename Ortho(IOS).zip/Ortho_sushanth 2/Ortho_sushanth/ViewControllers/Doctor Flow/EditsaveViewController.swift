//
//  EditsaveViewController.swift
//  Ortho_sushanth
//
//  Created by Sail L1 on 18/12/23.
//

import UIKit

class EditsaveViewController: BasicVC {

    @IBOutlet weak var nameTxt: UITextField!
    
    @IBOutlet weak var idTxt: UITextField!
    
    @IBOutlet weak var contactTxt: UITextField!
    
    @IBOutlet weak var ageTxt: UITextField!
    
    @IBOutlet weak var genderTxt: UITextField!
    
    @IBOutlet weak var heightTxt: UITextField!
    
    @IBOutlet weak var weightTxt: UITextField!
    
    @IBOutlet weak var dosTxt: UITextField!
    
    var patientIDVariable : String = ""
    var weightData = ""
    var patientDetails : [PatientDetailsData] = []
    var weightArray = ["0 Kg"] // Start with 0 Kg

    
    override func viewDidLoad() {
        super.viewDidLoad()
        postApi(PatientID: patientIDVariable)
        for kg in 1...10 {
            weightArray.append("\(kg) Kg")
        }
    }
    
    @IBAction func addTaskTap(_ sender: Any) {
        let storyBoard: UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "TaskPageVC") as! TaskPageVC
        vc.titleName = "Add Task"
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func editTask(_ sender: Any) {
        let storyBoard: UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "TaskPageVC") as! TaskPageVC
        vc.titleName = "Edit Task"
        self.navigationController?.pushViewController(vc, animated: true)
    }

    @IBAction func editWeightTask(_ sender: Any) {
        
        let alertController = UIAlertController(title: nil, message: nil, preferredStyle: .actionSheet)
        for weight in weightArray {
            let action = UIAlertAction(title: weight, style: .default) { _ in
                self.weightData = weight
                print("Selected weight: \(weight)")
            }
            alertController.addAction(action)
        }
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
        alertController.addAction(cancelAction)
        alertController.popoverPresentationController?.sourceView = self.view
        present(alertController, animated: true, completion: nil)
    }

    
    @IBAction func saveBtn(_ sender: Any) {
        if weightData == "" {
           showToast("Choose the Weight to Carry")
        }else{
            postAPI()
        }
        
    }
    @IBAction func backBtn(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
}
extension EditsaveViewController{
    func postApi(PatientID : String ){
        let formDatas : [String : Any] = ["pat_id": PatientID]
        self.startIndicator()
        APIHandler().postAPIValues(type: PatientDetailsModel.self, apiUrl: ApiList.patientDetailsApi  , method: "POST", formData: formDatas) { Result in
            switch Result {
            case .success(let data):
                DispatchQueue.main.async {[self] in
                    self.stopIndicator()
                    if data.status{
                        self.patientDetails = data.data
                        idTxt.text = patientDetails.first?.patID
                        nameTxt.text = patientDetails.first?.patName
                        contactTxt.text = patientDetails.first?.patContact
                        ageTxt.text = patientDetails.first?.patAge
                        genderTxt.text = patientDetails.first?.patGender
                        heightTxt.text = patientDetails.first?.patHeight
                        weightTxt.text = patientDetails.first?.patWeight
                        dosTxt.text = patientDetails.first?.patDOS
                        
                    }
                    
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async {
                    self.stopIndicator()
                    self.showAlert(title: "Failure", message: "Something Went Wrong", okActionHandler: {})
                }
            }
        }
    }
    func postAPI(){
        self.startIndicator()
        let apiUrl = ApiList.editPatientApi
        let formData: [String: Any] = [
                "pat_id": self.idTxt.text ?? "",
                "pat_name": nameTxt.text ?? "",
                "pat_age": ageTxt.text ?? "",
                "pat_contact": contactTxt.text ?? "",
                "pat_height": heightTxt.text ?? "",
                "pat_weight": weightTxt.text ?? "",
                "pat_dos": dosTxt.text ?? "",
                "weight_to_carry": weightData,
                "pat_gender": genderTxt.text ?? ""
            ]
        APIHandler().postAPIValues(type: CommonPostResponseModel.self, apiUrl: apiUrl, method: "POST", formData: formData) {  result in
            switch result {
            case .success(let data):
                DispatchQueue.main.async {
                    self.stopIndicator()
                    if data.status{
                        self.showAlert(title: "Success", message: data.message, okActionHandler: {
                            self.pushToViewController(withIdentifier: "DashBoardViewController")
                        })
                    }else{
                        self.showToast(data.message)
                    }
                }
                
            case .failure(let error):
                print(error)
                DispatchQueue.main.async {
                    self.stopIndicator()
                    self.showAlert(title: "Failure", message: "Something Went Wrong", okActionHandler: {})
                }
            }
        }
    }
}
