//
//  SideMenuController.swift
//  Ortho_sushanth
//
//  Created by Sail L1 on 20/12/23.
//

import UIKit

protocol SideMenuTap {
    func sendVc(int : Int)
}

class SideMenuController: BasicVC {

    @IBOutlet weak var subview: UIView!
    
    var delegate : SideMenuTap!
    
    var name = String()
    
    override func viewDidLoad() {
        super.viewDidLoad()

//        subview.layer.cornerRadius = 10
        print(name)
    }
    

    @IBAction func profileTap(_ sender: Any) {
//       
        delegate?.sendVc(int: 0)
        self.dismiss(animated: false, completion: nil)
    }
    
    @IBAction func logTap(_ sender: Any) {
        delegate?.sendVc(int: 1)
        self.dismiss(animated: false, completion: nil)
    }
    @IBAction func cancelTap(_ sender: Any) {
        
        self.dismiss(animated: false, completion: nil)
    }
}
