//
//  AddPatinetViewController.swift
//  Ortho_sushanth
//
//  Created by Sail L1 on 18/12/23.
//

import UIKit

class AddPatinetViewController: BasicVC ,UIImagePickerControllerDelegate , UINavigationControllerDelegate{
    
    
    @IBOutlet weak var patientNameLabel: UITextField!
    
    @IBOutlet weak var patientIdLabel: UITextField!
    
    @IBOutlet weak var contactLabel: UITextField!
    
    @IBOutlet weak var ageLabel: UITextField!
    @IBOutlet weak var genderLabel: UITextField!
    
    @IBOutlet weak var dosLabel: UITextField!
    @IBOutlet weak var weightLabel: UITextField!
    @IBOutlet weak var heightLabel: UITextField!
    
    @IBOutlet weak var profileImage: UIImageView!
    
    
    
    let imagePicker = UIImagePickerController()
   
   
    var selectedProfileImage = [UIImage]()
 
   
  
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        imagePicker.delegate = self
        imagePicker.allowsEditing = true
   
        
    }
    
    @IBAction func backBtn(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    @IBAction func saveBtn(_ sender: Any) {
        if patientIdLabel.text?.isEmpty == true {
            showToast("Enter the Patient ID")
        }else if patientNameLabel.text?.isEmpty == true {
            showToast("Enter the Patient Name")
        }else{
            postAPI()
        }
       
       
    }
    
    
    @IBAction func editImage(_ sender: Any) {
        
        presentImagePicker()
    }
    
    
}
extension AddPatinetViewController{
    func postAPI(){
        self.startIndicator()
        let apiUrl = ApiList.addpatientApi
        let formData: [String: Any] = [
                "pat_id": self.patientIdLabel.text ?? "",
                "pat_name": patientNameLabel.text ?? "",
                "pat_age": ageLabel.text ?? "",
                "pat_contact": contactLabel.text ?? "",
                "pat_height": heightLabel.text ?? "",
                "pat_weight": weightLabel.text ?? "",
                "pat_dos": dosLabel.text ?? "",
                "weight_to_carry": "0 Kg",
                "pat_gender": genderLabel.text ?? ""
            ]
        APIHandler().postAPIValues(type: CommonPostResponseModel.self, apiUrl: apiUrl, method: "POST", formData: formData) {  result in
            switch result {
            case .success(let data):
                DispatchQueue.main.async {
                    self.stopIndicator()
                    if data.status{
                        self.uploadProfile()
                        self.showAlert(title: "Success", message: data.message, okActionHandler: {
                            self.pushToViewController(withIdentifier: "DashBoardViewController")
                        })
                    }else{
                        self.showToast(data.message)
                    }
                }
                
            case .failure(let error):
                print(error)
                DispatchQueue.main.async {
                    self.stopIndicator()
                    self.showAlert(title: "Failure", message: "Something Went Wrong", okActionHandler: {})
                }
            }
        }
    }
    
    
    
    func presentImagePicker() {
           let alert = UIAlertController(title: "Choose Image", message: nil, preferredStyle: .actionSheet)
           alert.addAction(UIAlertAction(title: "Camera", style: .default, handler: { _ in
               self.openCamera()
               
           }))
           alert.addAction(UIAlertAction(title: "Gallery", style: .default, handler: { _ in
               self.openGallery()
           }))
           alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
           present(alert, animated: true, completion: nil)
       }
       
       
    
       
       func openCamera() {
           if UIImagePickerController.isSourceTypeAvailable(.camera) {
               imagePicker.sourceType = .camera
               selectedProfileImage.removeAll()
               present(imagePicker, animated: true, completion: nil)
           } else {
               print("Camera not available")
           }
       }
       
       func openGallery() {
           imagePicker.sourceType = .photoLibrary
           selectedProfileImage.removeAll()
           present(imagePicker, animated: true, completion: nil)
       }

    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let pickedImage = info[UIImagePickerController.InfoKey.editedImage] as? UIImage {
            
            
            selectedProfileImage.append(pickedImage)
            profileImage.image = pickedImage
           
            
        }
        picker.dismiss(animated: true, completion: nil)
    }
       func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
           picker.dismiss(animated: true, completion: nil)
       }
    
    
    func uploadProfile() {
        
        let apiURL = ApiList.profile
        print("API URL:", apiURL)

        let boundary = UUID().uuidString
        var request = URLRequest(url: URL(string: apiURL)!)
        request.httpMethod = "POST"
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
        var body = Data()
     
        var formData = [String: String]()

        formData["pat_id"] = self.patientIdLabel.text ?? ""
       

           

        for (key, value) in formData {
            body.append(contentsOf: "--\(boundary)\r\n".utf8)
            body.append(contentsOf: "Content-Disposition: form-data; name=\"\(key)\"\r\n\r\n".utf8)
            body.append(contentsOf: "\(value)\r\n".utf8)
        }


        let fieldNames = ["image"]

        for (index, image) in selectedProfileImage.enumerated() {
           
            let fieldName = fieldNames[index]

            let imageData = image.jpegData(compressionQuality: 0.8)!
            body.append(contentsOf: "--\(boundary)\r\n".utf8)
            body.append(contentsOf: "Content-Disposition: form-data; name=\"\(fieldName)\"; filename=\"\(UUID().uuidString).jpg\"\r\n".utf8)
            body.append(contentsOf: "Content-Type: image/jpeg\r\n\r\n".utf8)
            body.append(contentsOf: imageData)
            body.append(contentsOf: "\r\n".utf8)


        }

        // Add closing boundary
        body.append(contentsOf: "--\(boundary)--\r\n".utf8) // Close the request body

        request.httpBody = body

        let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
            if let error = error {
                print("Error: \(error)")
                // Handle the error, e.g., show an alert to the user
                return
            }
            
            if let httpResponse = response as? HTTPURLResponse {
                print("Status code: \(httpResponse.statusCode)")
                self.selectedProfileImage.removeAll()
                if let data = data {
                    
                    // print("Response Data:", String(data: data, encoding: .utf8) ?? "")
                    
                    if let responseData = String(data: data, encoding: .utf8) {
                        if let jsonData = responseData.data(using: .utf8) {
                            do {
                                if let json = try JSONSerialization.jsonObject(with: jsonData, options: []) as? [String: Any] {
                                    if let status = json["status"] as? String, let message = json["message"] as? String {
                                        
                                        print(message)
                                        print(status)
                                        
//                                        DispatchQueue.main.async {
//                                            if let nav = self.navigationController {
//                                                DataManager.shared.sendMessage(title: "Message", message: message, navigation: nav)
//                                            }
//                                        }
                                    }
                                }
                            } catch {
                                print("Error parsing JSON: \(error)")
                            }
                        }
                    }
                }
            }
            
        }

        task.resume()
    }
}

