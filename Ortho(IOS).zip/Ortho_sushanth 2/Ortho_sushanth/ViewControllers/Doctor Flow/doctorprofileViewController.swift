//
//  doctorprofileViewController.swift
//  Ortho_sushanth
//
//  Created by Sail L1 on 20/12/23.
//

import UIKit

class doctorprofileViewController: BasicVC {

    @IBOutlet weak var doctorNameLabel: UILabel!
    
    @IBOutlet weak var doctorIdLabel: UILabel!
    @IBOutlet weak var AgeLabel: UILabel!
    @IBOutlet weak var genderLabel: UILabel!
    @IBOutlet weak var emailLabel: UILabel!
    @IBOutlet weak var contactLabel: UILabel!
    var getID = UserDefaultsManager.shared.getUserId()
    var doctorLogin : DocProfileModel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        getApi()
        
    }
        
    func getApi(){
        
        self.startIndicator()
        
        APIHandler().getAPIValues(type: DocProfileModel.self, apiUrl: "\(ApiList.doctorProfile)doc_id=\(getID ?? "")", method: "GET") { Result in
            switch Result {
            case .success(let data):
                DispatchQueue.main.async {
                    self.doctorLogin = data
                    self.stopIndicator()
                    self.doctorNameLabel.text = data.data.docName
                    self.doctorIdLabel.text = data.data.docID
                    self.genderLabel.text = data.data.docGender
                    self.AgeLabel.text = data.data.docAge
                    self.emailLabel.text = data.data.docMail
                    self.contactLabel.text = data.data.docContact
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async {
                    self.stopIndicator()
                    self.showAlert(title: "Failure", message: "Something Went Wrong", okActionHandler: {})
                }
            }
        }
    }
    
    @IBAction func backBtn(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    @IBAction func editPageButton(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "DoctorEditProfileVC") as! DoctorEditProfileVC
        self.navigationController?.pushViewController(vc, animated: true)
    }
}


