//
//  TaskPageVC.swift
//  Ortho_sushanth
//
//  Created by SAIL on 25/01/24.
//

import UIKit

class TaskPageVC: BasicVC {

    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var taskTableView: UITableView!{
        didSet{
            self.taskTableView.delegate = self
            self.taskTableView.dataSource = self
            self.taskTableView.allowsMultipleSelection = true
        }
    }
    var titleName : String = ""
    var ViewTaskList : [ViewTaskListData] = []
    var listDataAdded: [String] = []
    var getID = UserDefaultsManager.shared.getPatientnamekey() ?? ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        titleLabel.text = titleName
        let cel = UINib(nibName: "TasksTableViewCell", bundle: nil)
       taskTableView.register(cel, forCellReuseIdentifier: "TasksTableViewCell")
         
        getApi()
       
    }
    
    @IBAction func backBtn(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    @IBAction func submitButton(_ sender: Any) {
        if listDataAdded.isEmpty == true{
            showToast("Select the video title's")
        }else{
            if titleName == "Add Task" {
                self.addPostApi()
            } else if titleName == "Edit Task" {
                self.editPostApi()
            }
            
        }
    }

}
extension TaskPageVC{
    func getApi(){
        self.startIndicator()
        APIHandler().getAPIValues(type: ViewTaskListModel.self, apiUrl: ApiList.viewTaskApi  , method: "GET") { Result in
            switch Result {
            case .success(let data):
                DispatchQueue.main.async {
                    self.ViewTaskList = data.data
//                    self.filteredPatientListData = data.data
                    self.taskTableView.reloadData()
                    self.stopIndicator()
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async {
                    self.stopIndicator()
                    self.showAlert(title: "Failure", message: "Something Went Wrong", okActionHandler: {})
                }
            }
        }
    }
    func editPostApi(){
        
        self.startIndicator()
        let formData : [String : Any] = ["patient_id": getID,
                                            "selected_titles": listDataAdded]
        APIHandler().postAPIValues(type: CommonPostResponseModel.self, apiUrl: "\(ApiList.editTaskApi)", method: "POST", formData: formData) { Result in
            switch Result {
            case .success(let data):
                DispatchQueue.main.async {
                    self.stopIndicator()
                    if data.status{
                        self.showAlert(title: "Success", message: data.message,okActionHandler: {
                            self.pushToViewController(withIdentifier: "DashBoardViewController")
                        })
                    }else{
                        self.showToast(data.message)
                    }
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async {
                    self.stopIndicator()
                    self.showAlert(title: "Failure", message: "Something Went Wrong", okActionHandler: {})
                }
            }
        }
    }
    
    func addPostApi(){
        
        self.startIndicator()
        let formData : [String : Any] = ["patient_id": getID,
                                        "selected_titles": listDataAdded]
        APIHandler().postAPIValues(type: CommonPostResponseModel.self, apiUrl: "\(ApiList.addTaskApi)", method: "POST", formData: formData) { Result in
            switch Result {
            case .success(let data):
                DispatchQueue.main.async {
                    self.stopIndicator()
                    if data.status{
                        self.showAlert(title: "Success", message: data.message,okActionHandler: {
                            self.pushToViewController(withIdentifier: "DashBoardViewController")
                        })
                    }else{
                        self.showToast(data.message)
                    }
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async {
                    self.stopIndicator()
                    self.showAlert(title: "Failure", message: "Something Went Wrong", okActionHandler: {})
                }
            }
        }
    }
       
}
extension TaskPageVC: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return ViewTaskList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TasksTableViewCell", for: indexPath) as! TasksTableViewCell
        cell.nameLbl.text = ViewTaskList[indexPath.row].taskName
        
print("listDataAdded : \(listDataAdded)")
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        guard let cell = tableView.cellForRow(at: indexPath) else { return }
        cell.accessoryType = .checkmark
        let selectedExercise = ViewTaskList[indexPath.row].taskName
        
        if !listDataAdded.contains(selectedExercise) {
            listDataAdded.append(selectedExercise)
            
        }
        print(selectedExercise)
    }

    func tableView(_ tableView: UITableView, didDeselectRowAt indexPath: IndexPath) {
        guard let cell = tableView.cellForRow(at: indexPath) else { return }
        cell.accessoryType = .none
        let deselectedExercise = ViewTaskList[indexPath.row].taskName
        
        if let index = listDataAdded.firstIndex(of: deselectedExercise) {
            listDataAdded.remove(at: index)
            print("listDataAdded : \(listDataAdded)")
        }
       

    }
}
