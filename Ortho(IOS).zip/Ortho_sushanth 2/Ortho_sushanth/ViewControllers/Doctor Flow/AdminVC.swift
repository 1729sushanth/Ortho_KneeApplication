//
//  AdminVC.swift
//  Ortho_sushanth
//
//  Created by Sail L1 on 18/12/23.
//

import UIKit

class AdminVC: UIViewController {
    @IBOutlet weak var titleLoginLabel: UILabel!
    @IBOutlet weak var docIDTxt: UITextField!
    @IBOutlet weak var docPasswordTxt: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
    @IBAction func doctorBtn(_ sender: Any) {
        UserDefaultsManager.shared.saveUserName("Doctor")
        let storyBoard: UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "DoctorLoginViewController") as! DoctorLoginViewController
          self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func patientBtn(_ sender: Any) {
        UserDefaultsManager.shared.saveUserName("Patient")
        let storyBoard: UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "DoctorLoginViewController") as! DoctorLoginViewController
          self.navigationController?.pushViewController(vc, animated: true)
    }
}
