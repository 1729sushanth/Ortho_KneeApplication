//
//  TasksTableViewCell.swift
//  Ortho_sushanth
//
//  Created by Sail L1 on 20/12/23.
//

import UIKit

import UIKit

class TasksTableViewCell: UITableViewCell {
    
    @IBOutlet weak var nameLbl: UILabel!
    @IBOutlet weak var clickImage: UIImageView!
    
  
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    
    }
}
