<?php
require("conn.php");

if ($_SERVER["REQUEST_METHOD"] == "GET") {
    // Check connection
    if ($conn->connect_error) {
        $response = array(
            'status' => false,
            'message' => 'Connection failed: ' . $conn->connect_error,
            'data' => null
        );
    } else {
        // Query to get all video information including title and description
        $sql = "SELECT video_path, video_title, video_description FROM video_data";
        $result = mysqli_query($conn, $sql);

        if ($result->num_rows > 0) {
            $videosArray = array();

            // Fetch all rows and store in an array
            while ($row = $result->fetch_assoc()) {
                $videoItem = array(
                    'url' => $row['video_path'],
                    'title' => $row['video_title'],
                    'description' => $row['video_description']
                    // Add other video information as needed
                );
                $videosArray[] = $videoItem;
            }

            $response = array(
                'status' => true,
                'message' => 'Videos found',
                'data' => $videosArray
            );
        } else {
            $response = array(
                'status' => true,
                'message' => 'No videos found',
                'data' => null
            );
        }

        $conn->close();
    }

    // Return JSON response
    header('Content-Type: application/json');
    echo json_encode($response);
} else {
    echo "Invalid request";
}
?>
