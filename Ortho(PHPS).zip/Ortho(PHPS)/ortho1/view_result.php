<?php
require_once('dbh.php');


$pat_id = $_GET['pat_id'];
$loginqry = "SELECT * FROM points WHERE pat_id = '$pat_id'";

$qry = mysqli_query($dbconn, $loginqry);

if(mysqli_num_rows($qry) > 0){
	
	$userObj = mysqli_fetch_assoc($qry); 
	$response['status'] = true;
	$response['message']= "Result shown Successfully";
	$response['data'] = $userObj;	
}
else{
	$response['status'] = false;
	$response['message']= "Result Failed";	
}
header('Content-Type: application/json; charset=UTF-8');
echo json_encode($response);
?>