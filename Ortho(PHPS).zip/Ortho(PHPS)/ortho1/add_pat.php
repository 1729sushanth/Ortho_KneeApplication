<?php

include 'dbh.php';

$pat_id = $_POST['pat_id'];
//$pat_pass = $_POST['pat_pass'];
$pat_name = $_POST['pat_name'];
$pat_contact = $_POST['pat_contact'];
$pat_age = $_POST['pat_age'];
$pat_gender = $_POST['pat_gender'];
$pat_height = $_POST['pat_height'];
$pat_weight = $_POST['pat_weight'];
$pat_dos = $_POST['pat_dos'];  // Assuming pat_dos is in the format YYYY-MM-DD HH:MM:SS

$pat_pass = substr($pat_id, -4);

// Check if pat_id already exists
$check_query = "SELECT * FROM pat_details WHERE pat_id = '$pat_id'";
$check_result = mysqli_query($dbconn, $check_query);

if (mysqli_num_rows($check_result) > 0) {
    // pat_id already exists
    $response['status'] = false;
    $response['message'] = "Patient ID already exists";
} else {
    // Insert new record
    $loginqry = "INSERT INTO pat_details (pat_id, pat_pass, pat_name, pat_contact, pat_age, pat_gender, pat_height, pat_weight, pat_dos) 
                 VALUES ('$pat_id', '$pat_pass', '$pat_name', '$pat_contact', '$pat_age', '$pat_gender', '$pat_height', '$pat_weight', '$pat_dos')";

    $res = mysqli_query($dbconn, $loginqry);

    if ($res) {
        $response['status'] = true;
        $response['message'] = "Patient Added Successfully";
    } else {
        $response['status'] = false;
        $response['message'] = "Signup Failed";
    }
}

header('Content-Type: application/json; charset=UTF-8');
echo json_encode($response);
?>
