<?php
// Include the database connection configuration
include("conn.php");

// Create an associative array to hold the API response
$response = array();

try {
    // Check if the request method is POST
    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        // Check if necessary fields are present for update
        if (isset($_POST['doc_id'], $_POST['doc_name'], $_POST['doc_gender'], $_POST['doc_age'], $_POST['doc_contact'], $_POST['doc_mail'])) {
            // Assign POST data to variables
            $doc_id = $_POST['doc_id'];
            $doc_name = $_POST['doc_name'];
            $doc_gender = $_POST['doc_gender'];
            $doc_age = $_POST['doc_age'];
            $doc_contact = $_POST['doc_contact'];
            $doc_mail = $_POST['doc_mail'];

            // Update data in doc_det table by doc_id
            $updateDocSql = "UPDATE `doc_det` SET `doc_name` = ?, `doc_gender` = ?, `doc_age` = ?, `doc_contact` = ?, `doc_mail` = ? WHERE `doc_id` = ?";
            $stmt = $conn->prepare($updateDocSql);
            $stmt->bind_param('sssssi', $doc_name, $doc_gender, $doc_age, $doc_contact, $doc_mail, $doc_id);

            if ($stmt->execute()) {
                $response['status'] = true;
                $response['message'] = "Profile updated successfully for doc_id: $doc_id";
            } else {
                $response['status'] = false;
                $response['message'] = "Error updating profile for doc_id: $doc_id";
            }
        } else {
            $response['status'] = false;
            $response['message'] = "Required fields for update are missing";
        }
    } else {
        $response['status'] = false;
        $response['message'] = "Invalid request method";
    }
} catch (mysqli_sql_exception $e) {
    // Handle any exceptions
    $response['status'] = false;
    $response['message'] = "Error: " . $e->getMessage();
}

// Convert the response array to JSON and echo it
header('Content-Type: application/json');
echo json_encode($response);

// Close the database connection
$conn->close();
?>
