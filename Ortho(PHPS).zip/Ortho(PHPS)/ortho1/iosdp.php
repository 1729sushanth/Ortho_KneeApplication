<?php
require("dbh1.php");

$response = array();

if (isset($_POST["pat_id"]) && isset($_FILES["image"])) {
    $pat_id = $_POST["pat_id"];
    $fileName = $_FILES["image"]["name"];
    $tempName = $_FILES["image"]["tmp_name"];
    $folder = "image/" . $fileName;

    if (move_uploaded_file($tempName, $folder)) {
        $sql = "UPDATE pat_details SET dp = :folder WHERE pat_id = :pat_id";
        
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':folder', $folder);
        $stmt->bindParam(':pat_id', $pat_id);

        if ($stmt->execute()) {
            $response['status'] = 'success';
            $response['message'] = 'Data inserted successfully.';
        } else {
            $response['status'] = 'error';
            $response['message'] = 'Data not inserted. Error: ' . $stmt->errorInfo()[2];
        }
    } else {
        $response['status'] = 'error';
        $response['message'] = 'File upload failed.';
    }
} else {
    $response['status'] = 'error';
    $response['message'] = 'Invalid request.';
}

header('Content-Type: application/json');
echo json_encode($response);
?>