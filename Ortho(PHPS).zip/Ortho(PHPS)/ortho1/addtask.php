<?php
// Include the database connection configuration
require("dbh1.php");

// Create an associative array to hold the API response
$response = array();

try {
    // Check if the request method is POST
    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        // Assuming you have the patient_id and selected_titles as POST parameters
        $patient_id = $_POST['patient_id'];
        $selected_titles_array = json_decode($_POST['selected_titles']);

        // Check if a record with the same patient_id already exists
        $check_sql = "SELECT * FROM addtask WHERE patient_id = :patient_id";
        $check_stmt = $conn->prepare($check_sql);
        $check_stmt->bindParam(':patient_id', $patient_id);
        $check_stmt->execute();
        $existing_record = $check_stmt->fetch();

        if (!$existing_record) {
            // No existing record found, proceed with insertion
            $sql = "INSERT INTO addtask (patient_id, selected_titles) VALUES (:patient_id, :selected_titles)";
            $stmt = $conn->prepare($sql);
            $stmt->bindParam(':patient_id', $patient_id);
            $stmt->bindParam(':selected_titles', $_POST['selected_titles']);
            $stmt->execute();

            $response['status'] = true;
            $response['message'] = "Data inserted successfully";
        } else {
            // Existing record found, return a message indicating that insertion is not allowed
            $response['status'] = false;
            $response['message'] = "Data for patient_id $patient_id already exists";
        }
    } else {
        $response['status'] = false;
        $response['message'] = "Invalid request method. Only POST requests are allowed.";
    }
} catch (Exception $e) {
    // Handle any exceptions
    $response['status'] = false;
    $response['message'] = "Error: " . $e->getMessage();
}

// Convert the response array to JSON and echo it
header('Content-Type: application/json');
echo json_encode($response);

// Close the statement and database connection
if (isset($stmt)) {
    $stmt = null;
}
if (isset($check_stmt)) {
    $check_stmt = null;
}
$conn = null;
?>
