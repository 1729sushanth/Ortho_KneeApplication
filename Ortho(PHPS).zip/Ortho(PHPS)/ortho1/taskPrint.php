<?php
// Check if the form is submitted or if data retrieval is requested
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Assuming you have a connection to your database
    // Replace these details with your actual database connection parameters
    require("dbh.php");

    
        // Retrieve data based on id and date
        $id = mysqli_real_escape_string($dbconn, $_POST['id']);
        $date = mysqli_real_escape_string($dbconn, $_POST['date']);

        $sql = "SELECT * FROM dotask WHERE id = '$id' AND date = '$date'";
        $result = $dbconn->query($sql);

        if ($result->num_rows > 0) {
            // Data found, return in JSON format
            $row = $result->fetch_assoc();
            $response = array('status' => 'success', 'data' => $row);
        } else {
            // No matching data found
            $response = array('status' => 'error', 'message' => 'No matching data found');
        }

        // Close the database connection
        $dbconn->close();

        // Return JSON response
        header('Content-Type: application/json');
        echo json_encode($response);
    }
?>
