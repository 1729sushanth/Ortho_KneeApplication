<?php
// Include the database connection configuration
include("dbh1.php");

// Create an associative array to hold the API response
$response = array();

try {
    // Check if the request method is POST
    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        // Check if necessary fields are present for update
        if (isset($_POST['pat_id'], $_POST['pat_name'], $_POST['pat_contact'], $_POST['pat_age'], $_POST['pat_gender'], $_POST['pat_height'], $_POST['pat_weight'], $_POST['pat_dos'])) {
            // Assign POST data to variables
            $pat_id = $_POST['pat_id'];
            $pat_name = $_POST['pat_name'];
            $pat_contact = $_POST['pat_contact'];
            $pat_age = $_POST['pat_age'];
            $pat_gender = $_POST['pat_gender'];
            $pat_height = $_POST['pat_height'];
            $pat_weight = $_POST['pat_weight'];
            $pat_dos = $_POST['pat_dos'];
            //$weight_to_carry = $_POST['weight_to_carry'];

            // Update data in pat_details table by pat_id
            $updateDocSql = "UPDATE `pat_details` SET `pat_name` = :pat_name, `pat_contact` = :pat_contact, `pat_age` = :pat_age, `pat_gender` = :pat_gender, `pat_height` = :pat_height, `pat_weight` = :pat_weight, `pat_dos` = :pat_dos WHERE `pat_id` = :pat_id";
            $stmt = $conn->prepare($updateDocSql);
            $stmt->bindParam(':pat_id', $pat_id);
            $stmt->bindParam(':pat_name', $pat_name);
            $stmt->bindParam(':pat_contact', $pat_contact);
            $stmt->bindParam(':pat_age', $pat_age);
            $stmt->bindParam(':pat_gender', $pat_gender);
            $stmt->bindParam(':pat_height', $pat_height);
            $stmt->bindParam(':pat_weight', $pat_weight);
            $stmt->bindParam(':pat_dos', $pat_dos);
            //$stmt->bindParam(':weight_to_carry', $weight_to_carry);

            if ($stmt->execute()) {
                $response['status'] = true;
                $response['message'] = "Profile updated successfully for pat_id: $pat_id";
            } else {
                $response['status'] = false;
                $response['message'] = "Error updating profile for pat_id: $pat_id";
            }
        } else {
            $response['status'] = false;
            $response['message'] = "Required fields for update are missing";
        }
    } else {
        $response['status'] = false;
        $response['message'] = "Invalid request method";
    }
} catch (PDOException $e) {
    // Handle any exceptions
    $response['status'] = false;
    $response['message'] = "Error: " . $e->getMessage();
}

// Convert the response array to JSON and echo it
header('Content-Type: application/json');
echo json_encode($response);

// Close the database connection
$conn = null;
?>
