<?php
// Include the database connection configuration
require("dbh1.php");

// Create an associative array to hold the API response
$response = array();

try {
    // Check if the request method is POST
    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        // Assuming you have the patient_id, selected_titles, feedback, and date as POST parameters
        $patient_id = $_POST['patient_id'];
        $selected_titles_array = json_decode($_POST['selected_titles']);
        $feedback = $_POST['feedback'];

        // Set the date to the current date
        $date = date('Y-m-d');

        // Check if feedback has already been provided within the last 24 hours
        $check_feedback_sql = "SELECT * FROM patienttask WHERE patient_id = :patient_id AND date >= DATE_SUB(NOW(), INTERVAL 1 DAY)";
        $check_feedback_stmt = $conn->prepare($check_feedback_sql);
        $check_feedback_stmt->bindParam(':patient_id', $patient_id);
        $check_feedback_stmt->execute();
        $existing_feedback = $check_feedback_stmt->fetch();

        if (!$existing_feedback) {
            // No feedback found within the last 24 hours, proceed with insertion
            $sql = "INSERT INTO patienttask (patient_id, selected_titles, feedback, date) VALUES (:patient_id, :selected_titles, :feedback, :date)";
            $stmt = $conn->prepare($sql);
            $stmt->bindParam(':patient_id', $patient_id);
            $stmt->bindParam(':selected_titles', $_POST['selected_titles']);
            $stmt->bindParam(':feedback', $feedback);
            $stmt->bindParam(':date', $date);
            $stmt->execute();

            $response['status'] = true;
            $response['message'] = "Feedback inserted successfully";
        } else {
            // Feedback already provided within the last 24 hours
            $response['status'] = false;
            $response['message'] = "Feedback can only be provided once in 24 hours";
        }
    } else {
        $response['status'] = false;
        $response['message'] = "Invalid request method. Only POST requests are allowed.";
    }
} catch (Exception $e) {
    // Handle any exceptions
    $response['status'] = false;
    $response['message'] = "Error: " . $e->getMessage();
}

// Convert the response array to JSON and echo it
header('Content-Type: application/json');
echo json_encode($response);

// Close the statement and database connection
if (isset($stmt)) {
    $stmt = null;
}
if (isset($check_feedback_stmt)) {
    $check_feedback_stmt = null;
}
$conn = null;
?>
