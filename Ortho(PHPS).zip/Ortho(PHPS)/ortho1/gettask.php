<?php
// Include the database connection configuration
require("dbh1.php");

// Create an associative array to hold the API response
$response = array();

try {
    // Check if the request method is POST
    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        // Assuming you have the patient_id as a POST parameter
        if(isset($_POST['patient_id'])) {
            $patient_id = $_POST['patient_id'];

            // Fetch selected_titles for the given patient_id
            $sql = "SELECT selected_titles FROM addtask WHERE patient_id = :patient_id";
            $stmt = $conn->prepare($sql);
            $stmt->bindParam(':patient_id', $patient_id);
            $stmt->execute();
            $result = $stmt->fetch();

            if ($result) {
                $response['status'] = true;
                $response['message'] = "Data retrieved successfully for patient_id $patient_id";
                $response['data'] = array(
                    array(
                        'patient_id' => $patient_id,
                        'selected_titles' => json_decode($result['selected_titles'])
                    )
                );
            } else {
                // If no data found, set status to false
                $response['status'] = false;
                $response['message'] = "No data found for patient_id $patient_id";
                $response['data'] = array();
            }
        } else {
            $response['status'] = false;
            $response['message'] = "Please provide patient_id parameter";
        }
    } else {
        $response['status'] = false;
        $response['message'] = "Invalid request method. Only POST requests are allowed.";
    }
} catch (Exception $e) {
    // Handle any exceptions
    $response['status'] = false;
    $response['message'] = "Error: " . $e->getMessage();
}

// Convert the response array to JSON and echo it
header('Content-Type: application/json');
echo json_encode($response, JSON_PRETTY_PRINT);

// Close the statement and database connection
if (isset($stmt)) {
    $stmt = null;
}
$conn = null;
?>
