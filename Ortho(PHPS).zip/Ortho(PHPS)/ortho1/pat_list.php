<?php
require_once('dbh.php');

$loginqry = "SELECT pat_id, pat_name, pat_age,dp FROM pat_details ORDER BY pat_id DESC LIMIT 5";

$qry = mysqli_query($dbconn, $loginqry);

if(mysqli_num_rows($qry) > 0){
	
	$i = 0;
	while($row = mysqli_fetch_assoc($qry)){
	    $student[$i]['pat_id'] = $row['pat_id'];
		$student[$i]['pat_name'] = $row['pat_name'];
		$student[$i]['pat_age'] = $row['pat_age'];
		$profileImage = $row['dp'];
        if (!empty($profileImage) && file_exists($profileImage)) {
            // Convert the image to base64
            $base64Image = base64_encode(file_get_contents($profileImage));
            $row['dp'] = $base64Image;
        } else {
            // Set a default image or handle the absence of the image
            $row['dp'] = ''; // You can set a default image here if needed
        }
		$student[$i]['dp'] = $row['dp'];
		$i = $i + 1;
	}
	$response['status'] = true;
	$response['message'] = "Top 5 most recently added patients";
	$response['data'] = $student;	
}
else{  
	$response['status'] = false;
	$response['message'] = "No Data";	
}

header('Content-Type: application/json; charset=UTF-8');
echo json_encode($response);
?>
