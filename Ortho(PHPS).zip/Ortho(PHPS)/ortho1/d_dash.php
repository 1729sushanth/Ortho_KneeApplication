<?php
require_once('dbh.php');

$loginqry = "SELECT pat_name, pat_age, pat_dos FROM pat_details ";

$qry = mysqli_query($dbconn, $loginqry);

if(mysqli_num_rows($qry) > 0){
	
	$i =0;
	while($row = mysqli_fetch_assoc($qry)){
	$student[$i]['pat_name'] = $row['pat_name'];
	$student[$i]['pat_age'] = $row['pat_age'];
	$student[$i]['pat_dos'] = $row['pat_dos'];
	$i = $i+1;
	}
	$response['status'] = true;
	$response['message']= "patient details";
	$response['data'] = $student;	
}
else{  
	$response['status'] = false;
	$response['message']= "No Data";	
}
header('Content-Type: application/json; charset=UTF-8');
echo json_encode($response);
?>