<?php
// Include the database connection configuration
require("dbh1.php");

// Create an associative array to hold the API response
$response = array();

try {
    // Check if the request method is POST
    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        // Assuming you have the patient_id, result, and date as POST parameters
        $patient_id = $_POST['patient_id'];
        $result = $_POST['result'];

        // Set the date to the current date
        $date = date('Y-m-d');

        // Check if result has already been provided within the last 24 hours
        $check_result_sql = "SELECT * FROM points WHERE patient_id = :patient_id AND date >= DATE_SUB(NOW(), INTERVAL 1 DAY)";
        $check_result_stmt = $conn->prepare($check_result_sql);
        $check_result_stmt->bindParam(':patient_id', $patient_id);
        $check_result_stmt->execute();
        $existing_result = $check_result_stmt->fetch();

        if (!$existing_result) {
            // No result found within the last 24 hours, proceed with insertion
            $sql = "INSERT INTO points (patient_id, result, date) VALUES (:patient_id, :result, :date)";
            $stmt = $conn->prepare($sql);
            $stmt->bindParam(':patient_id', $patient_id);
            $stmt->bindParam(':result', $result);
            $stmt->bindParam(':date', $date);
            $stmt->execute();

            $response['status'] = true;
            $response['message'] = "Result inserted successfully";
        } else {
            // Result already provided within the last 24 hours
            $response['status'] = false;
            $response['message'] = "Result can only be provided once in 24 hours";
        }
    } else {
        $response['status'] = false;
        $response['message'] = "Invalid request method. Only POST requests are allowed.";
    }
} catch (Exception $e) {
    // Handle any exceptions
    $response['status'] = false;
    $response['message'] = "Error: " . $e->getMessage();
}

// Convert the response array to JSON and echo it
header('Content-Type: application/json');
echo json_encode($response);

// Close the statement and database connection
if (isset($stmt)) {
    $stmt = null;
}
if (isset($check_result_stmt)) {
    $check_result_stmt = null;
}
$conn = null;
?>
