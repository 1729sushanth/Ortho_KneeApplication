<?php
// Database connection details
require("conn.php");

$uploadDir = "vid/".DIRECTORY_SEPARATOR;

$response = array();

try {
    // Check if the request method is POST and required fields are set
    if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['uploaded_file']) && isset($_POST['video_title']) && isset($_POST['video_description'])) {
        // Extract data from the request
        $file = $_FILES['uploaded_file'];
        $fileName = basename($file['name']);
        $uploadPath = $uploadDir . $fileName;
        $videoTitle = $_POST['video_title'];
        $videoDescription = $_POST['video_description'];

        // Move uploaded file to destination directory
        if (move_uploaded_file($file['tmp_name'], $uploadPath)) {
            // Prepare SQL statement for updating video_data table
            $sql_video_data = "INSERT INTO video_data (video_path, video_title, video_description) VALUES ('$uploadPath', '$videoTitle', '$videoDescription') 
                               ON DUPLICATE KEY UPDATE video_path = '$uploadPath', video_description = '$videoDescription', video_title = '$videoTitle'";

            // Execute SQL statement for video_data table
            $result_video_data = $conn->query($sql_video_data);

            // Check if the query was successful
            if ($result_video_data === TRUE) {
                // Insert video title into tasks table
                $sql_insert_task = "INSERT INTO tasks (task_name) VALUES ('$videoTitle')";
                if ($conn->query($sql_insert_task) === TRUE) {
                    $response = array(
                        "status" => true,
                        "message" => "Video information updated successfully"
                    );
                } else {
                    $response = array(
                        "status" => false,
                        "message" => "Error adding video title to tasks table: " . $conn->error
                    );
                }
            } else {
                $response = array(
                    "status" => false,
                    "message" => "Error updating video information: " . $conn->error
                );
            }
        } else {
            $response = array(
                "status" => false,
                "message" => "Error uploading the file"
            );
        }
    } else {
        $response = array(
            "status" => false,
            "message" => "Invalid request"
        );
    }
} catch (Exception $e) {
    $response = array(
        "status" => false,
        "message" => "Error: " . $e->getMessage()
    );
}

// Encode response to JSON format and echo it
echo json_encode($response);

// Close database connection
$conn->close();
?>
