<?php
require_once('dbh.php');

$response = array(); // Initialize the response array

if (isset($_GET['doc_id']) && isset($_GET['doc_pass'])) {
    $doc_id = $_GET['doc_id'];
    $doc_pass = $_GET['doc_pass'];

    // Use prepared statements to prevent SQL injection
    $loginqry = "SELECT * FROM doc_det WHERE doc_id = ? AND pass = ?";
    $stmt = mysqli_prepare($dbconn, $loginqry);
    mysqli_stmt_bind_param($stmt, "ss", $doc_id, $doc_pass);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if (mysqli_num_rows($result) > 0) {
        $userObj = mysqli_fetch_assoc($result);
        $response['status'] = true;
        $response['message'] = "Login Successfully";
        $response['data'] = $userObj;
    } else {
        $response['status'] = false;
        $response['message'] = "Login Failed";
    }

    mysqli_stmt_close($stmt); // Close the prepared statement
} else {
    $response['status'] = false;
    $response['message'] = "Incomplete or missing parameters";
}

header('Content-Type: application/json; charset=UTF-8');
echo json_encode($response);
?>
