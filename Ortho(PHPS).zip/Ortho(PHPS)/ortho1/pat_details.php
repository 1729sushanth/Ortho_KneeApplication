<?php
require("dbh1.php");

// Check if the request method is POST and 'pat_id' is set
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['pat_id'])) {
    $pat_id = $_POST['pat_id'];

    try {
        // Prepare a statement to select data
        $stmt = $conn->prepare("SELECT * FROM pat_details WHERE pat_id = :pat_id");
        $stmt->bindParam(':pat_id', $pat_id);
        $stmt->execute();

        // Fetch data as an associative array
        $dataRows = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Check if there are results
        if ($dataRows) {

            foreach ($dataRows as &$row) {
                $profileImage = $row['dp'];
                if (!empty($profileImage) && file_exists($profileImage)) {
                    // Convert the image to base64
                    $base64Image = base64_encode(file_get_contents($profileImage));
                    $row['dp'] = $base64Image;
                } else {
                    // Set a default image or handle the absence of the image
                    $row['dp'] = ''; // You can set a default image here if needed
                }
            }
            
            // Convert fetched data to JSON format
            $jsonResponse = json_encode($dataRows);

            
            
            // Output the JSON response
            header('Content-Type: application/json');
            
            // Output success message
            $response['status'] = true;
            $response['message'] = "Data found for the patient ID: $pat_id";
            $response['data'] = $dataRows;
            echo json_encode($response);
        } else {
            // Handle if no data found for the provided pat_id
            $response['status'] = false;
            $response['message'] = "No data found for the patient ID: $pat_id";
            echo json_encode($response);
        }
    } catch (PDOException $e) {
        // Handle PDO errors
        $response['status'] = false;
        $response['message'] = "Error: " . $e->getMessage();
        echo json_encode($response);
    }
} else {
    // Handle if 'pat_id' is not set in the POST request or if it's not a POST request
    $response['status'] = false;
    $response['message'] = "Patient ID not found in the request or invalid request method";
    echo json_encode($response);
}
?>
