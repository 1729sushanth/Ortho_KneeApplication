<?php
require_once('dbh.php');

$loginqry = "SELECT pat_id, pat_name, pat_contact FROM pat_details ";

$qry = mysqli_query($dbconn, $loginqry);

if(mysqli_num_rows($qry) > 0){
	
	$i =0;
	while($row = mysqli_fetch_assoc($qry)){
    $student[$i]['pat_id'] = $row['pat_id'];
	$student[$i]['pat_name'] = $row['pat_name'];
	$student[$i]['pat_contact'] = $row['pat_contact'];
	$i = $i+1;
	}
	$response['status'] = true;
	$response['message']= "contact details";
	$response['data'] = $student;	
}
else{  
	$response['status'] = false;
	$response['message']= "No Data";	
}
header('Content-Type: application/json; charset=UTF-8');
echo json_encode($response);
?>