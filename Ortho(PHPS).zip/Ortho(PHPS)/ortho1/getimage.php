<?php
$host = "localhost"; 
$username = "root"; 
$password = ""; 
$dbname = "ortho1"; 

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    // Set the PDO error mode to exception
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    // If there's an error in connecting to the database, create an error response
    $response = array(
        "status" => "error",
        "message" => "Connection failed: " . $e->getMessage(),
        "data" => null
    );
    // Output the response as JSON
    header('Content-Type: application/json');
    echo json_encode($response);
    // Terminate the script
    exit();
}

try {
    // Initialize an array to store the data
    $imageData = array();

    // Fetch data from 'questions' table
    $questionsQuery = "SELECT id, image FROM image";
    $stmt = $pdo->query($questionsQuery);

    if ($stmt->rowCount() > 0) {
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            // Store the id, and image URL in the array
            $imageData[] = array(
                'id' => $row['id'],
                'image' => $row['image']
            );
        }
        // If data is found, create a success response
        $response = array(
            "status" => "success",
            "message" => "Data found",
            "data" => $imageData
        );
    } else {
        // Handle case where no data is found
        $response = array(
            "status" => "error",
            "message" => "No data found",
            "data" => null
        );
    }

    // Output the response as JSON
    header('Content-Type: application/json');
    echo json_encode($response);
} catch(PDOException $e) {
    // If an error occurs, create an error response
    $response = array(
        "status" => "error",
        "message" => "Error: " . $e->getMessage(),
        "data" => null
    );
    // Output the response as JSON
    header('Content-Type: application/json');
    echo json_encode($response);
}

// Close the database connection
$pdo = null;
?>
