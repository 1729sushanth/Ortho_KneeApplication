<?php
// Include the database connection configuration
require("dbh1.php");

// Create an associative array to hold the API response
$response = array();

try {
    // Check if the request method is POST
    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        // Assuming you have the patient_id and date as POST parameters
        if(isset($_POST['patient_id']) && isset($_POST['date'])) {
            $patient_id = $_POST['patient_id'];
            $date = $_POST['date'];

            // Fetch selected_titles, feedback, and result for the given patient_id and date
            $fetch_data_sql = "SELECT selected_titles, feedback, result FROM patienttask LEFT JOIN points ON patienttask.patient_id = points.patient_id WHERE patienttask.patient_id = :patient_id AND DATE(patienttask.date) = :date ORDER BY patienttask.date DESC";
            $fetch_data_stmt = $conn->prepare($fetch_data_sql);
            $fetch_data_stmt->bindParam(':patient_id', $patient_id);
            $fetch_data_stmt->bindParam(':date', $date);
            $fetch_data_stmt->execute();
            $results = $fetch_data_stmt->fetchAll();

            // Check if data exists
            if ($results) {
                $response['status'] = true;
                $response['message'] = "Data retrieved successfully for patient_id $patient_id and date $date";
                $response['data'] = array();

                foreach ($results as $result) {
                    $response['data'][] = array(
                        'patient_id' => $patient_id,
                        'selected_titles' => !empty($result['selected_titles']) ? json_decode($result['selected_titles']) : '',
                        'feedback' => !empty($result['feedback']) ? $result['feedback'] : '',
                        'result' => !empty($result['result']) ? $result['result'] : ''
                    );
                }
            } else {
                $response['status'] = false;
                $response['message'] = "No result found for patient_id $patient_id and date $date";
                // Set data to empty array
                $response['data'] = array();
            }
        } else {
            $response['status'] = false;
            $response['message'] = "Please provide patient_id and date parameters";
        }
    } else {
        $response['status'] = false;
        $response['message'] = "Invalid request method. Only POST requests are allowed.";
    }
} catch (Exception $e) {
    // Handle any exceptions
    $response['status'] = false;
    $response['message'] = "Error: " . $e->getMessage();
}

// Convert the response array to JSON and echo it
header('Content-Type: application/json');
echo json_encode($response);

// Close the statement and database connection
if (isset($fetch_data_stmt)) {
    $fetch_data_stmt = null;
}
$conn = null;
?>
