<?php
// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Assuming you have a connection to your database
    // Replace these details with your actual database connection parameters
   require("dbh.php");

    // Sanitize input data
    $id = mysqli_real_escape_string($dbconn, $_POST['id']);
    $date = mysqli_real_escape_string($dbconn, $_POST['date']);
    $task = mysqli_real_escape_string($dbconn, $_POST['task']);
    $res = mysqli_real_escape_string($dbconn, $_POST['res']);
    $feed = mysqli_real_escape_string($dbconn, $_POST['fed']);


    // Insert data into the database
    $sql = "INSERT INTO dotask VALUES ('$id', '$date', '$task','$res','$feed')";
    if ($dbconn->query($sql) === TRUE) {
        // Data inserted successfully
        $response = array('status' => 'success', 'message' => 'Data inserted successfully');
    } else {
        // Error in insertion
        $response = array('status' => 'error', 'message' => 'Error: ' . $conn->error);
    }

    // Close the database connection
    $dbconn->close();

    // Return JSON response
    header('Content-Type: application/json');
    echo json_encode($response);
} else {
    // If the form is not submitted, return an error response
    $response = array('status' => 'error', 'message' => 'Form not submitted');
    header('Content-Type: application/json');
    echo json_encode($response);
}
?>
