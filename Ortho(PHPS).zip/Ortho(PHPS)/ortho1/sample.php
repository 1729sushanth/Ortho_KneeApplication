<?php
require("dbh2.php");

// Check if the form is submitted and required fields are set
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['patient_id']) && isset($_POST['date']) && isset($_POST['selected_titles'])) {
    $patient_id = $_POST['patient_id'];
    $date = $_POST['date'];
    $selected_titles = $_POST['selected_titles'];

    $response = array(); // Initialize the response array

    // Ensure selected_titles is an array and not an empty string
    if (!is_array($selected_titles)) {
        $response['status'] = false;
        $response['error'] = "Selected titles must be an array";
    } elseif (empty($selected_titles)) {
        $response['status'] = false;
        $response['error'] = "Selected titles cannot be empty";
    } else {
        // Prepare and bind the INSERT statement
        $stmt = $conn->prepare("INSERT INTO addtask (patient_id, selected_titles, date) VALUES (?, ?, ?)");

        // Bind parameters
        $stmt->bind_param("sss", $patient_id, $title, $date);

        // Iterate over the selected_titles array and insert each title into the database
        foreach ($selected_titles as $title) {
            // Execute the statement
            if ($stmt->execute()) {
                $response['status'] = true;
                $response['message'] = "Data stored successfully.";
            } else {
                $response['status'] = false;
                $response['message'] = "Failed to store data: " . $conn->error;
                break; // Stop processing if any title fails to insert
            }
        }

        // Close the statement
        $stmt->close();
    }

    // Output JSON response without slashes
    echo json_encode($response, JSON_UNESCAPED_SLASHES);
} else {
    $response['status'] = false;
    $response['error'] = "Invalid request method or Missing required fields";

    // Output JSON response without slashes
    echo json_encode($response, JSON_UNESCAPED_SLASHES);
}
?>
