<?php
require_once('dbh.php');
$servername = "localhost";
    $username_db = "root";
    $password_db = "";
    $dbname = "ortho1";

    $conn = new mysqli($servername, $username_db, $password_db, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

$sql = "SELECT pat_id, pat_name, pat_age, dp FROM pat_details ORDER BY pat_id DESC";

$result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Fetch the data and encode profile images as base64
        $patientList = array();
        while ($row = $result->fetch_assoc()) {
            $profileImage = $row['dp'];
            if (!empty($profileImage) && file_exists($profileImage)) {
                // Convert the image to base64
                $base64Image = base64_encode(file_get_contents($profileImage));
                $row['dp'] = $base64Image;
            } else {
                // Set a default image or handle the absence of the image
                $row['dp'] = ''; // You can set a default image here if needed
            }
            $patientList[] = $row;
        }

        $response['status'] = true;
	$response['message'] = "Top 5 most recently added patients";
	$response['data'] = $patientList;
        //echo $response;
    } 
else {  
    $response['status'] = false;
    $response['message'] = "No Data";    
}

header('Content-Type: application/json; charset=UTF-8');
echo json_encode($response);
?>
